import cv2
import numpy as np
import math

# median_cut function
# li_ori -> the original BGR
# li_change -> the 8 bits BGR
# the index of li_ori and li_change is consistent(one to one)
def median_cut(data, times, color, li_ori, li_change):
    size = data.shape[0]
    median_index = int(size/2)
    # sort the color
    data = data[data[:,color[times]].argsort()]


    if times == 7:       # time for us to get a value
        left_avg = [0]*3

        for i in range(0, median_index):
            left_avg[0] += data[i][0]
            left_avg[1] += data[i][1]
            left_avg[2] += data[i][2]
            li_ori.append([data[i][0], data[i][1], data[i][2]])
        left_avg[0] /= median_index
        left_avg[0] = int(left_avg[0])
        left_avg[1] /= median_index
        left_avg[1] = int(left_avg[1])
        left_avg[2] /= median_index
        left_avg[2] = int(left_avg[2])     # calculate the avg as the middle value (calculating the avg)

        # in the certain area, the BGR of the pixels are very close to the middle value
        # so maybe we don't need to calculate the euclidean one by one
        # but just assign the middle value to all the pixels in this area
        # if there are other areas, the pixel with the same BGR may be assigned with another middle value
        # at that time we need to choose the best, which has the shortest euclidean from the original BGR
        for i in range(0, median_index):
            li_change.append([left_avg[0], left_avg[1], left_avg[2]])

        right_avg = [0]*3
        for j in range(median_index, size):
            right_avg[0] += data[j][0]
            right_avg[1] += data[j][1]
            right_avg[2] += data[j][2]
            li_ori.append([data[j][0], data[j][1], data[j][2]])
        right_avg[0] /= (size - median_index)
        right_avg[0] = int(right_avg[0])
        right_avg[1] /= (size - median_index)
        right_avg[1] = int(right_avg[1])
        right_avg[2] /= (size - median_index)
        right_avg[2] = int(right_avg[2])
        for i in range(median_index, size):
            li_change.append([right_avg[0], right_avg[1], right_avg[2]])



        return

    else:
        times += 1  # next color
        data_left = data[0:median_index]
        data_right = data[median_index: size]
        median_cut(data_left, times, color, li_ori, li_change)
        median_cut(data_right, times, color, li_ori, li_change)

# read in the original image
img = cv2.imread('redapple.jpg')

# color list
color = [2, 1, 0, 2, 1, 0, 2, 1]  # which means R G B R G B R G

# get the image's height and width
height = img.shape[0]
width = img.shape[1]
#height = 408
#width = 408

# calculate the pixel number
size = height * width

# initialize a numpy array to store the pixels of the image
store = np.zeros(shape=(size,3))

k = 0

# 3 dimension -> 2 dimension
for i in range(0, height):
    for j in range(0, width):
        store[k] = img[i,j]   # store the pixels to the array
        k = k + 1

# empty list

li = []
li_ori = []
li_change = []
times = 0
median_cut(store, times, color, li_ori, li_change)

# change the list to tuple
# so that it's hashable and can be the key of a dictionary
li_ori_tuple = list(map(tuple,li_ori))


d = {li_ori_tuple[0]:li_change[0]}

# push into the dictionaryl
for i in range(0,len(li_ori_tuple)):
    if li_ori_tuple[i] in d:  # if the point already exist, we should choose the least euclidean distance
        vec0 = np.array(list(li_ori_tuple[i]))
        vec1 = np.array(d[li_ori_tuple[i]])
        vec2 = np.array(li_change[i])

        dist1 = np.linalg.norm(vec0 - vec1)
        dist2 = np.linalg.norm(vec0 - vec2)

        # check which euclidean is shorter
        if dist2 < dist1:
            d[li_ori_tuple[i]] = li_change[i]
    else:
        d[li_ori_tuple[i]] = li_change[i]


# img2 is the output image, we first read in the normal image and then modify it
img2 = cv2.imread('redapple.jpg')

for i in range(0, height):
    for j in range(0, width):
        key = tuple(img[i,j])
        img2[i,j] = d[key]      # modify the BGR

# store the image
cv2.imwrite("redapple2.jpg", img2)
cv2.imshow("img_24bits", img)         # show windows
cv2.imshow("img_8bits", img2)

cv2.waitKey()                               # hold windows open until user presses a key

cv2.destroyAllWindows()













