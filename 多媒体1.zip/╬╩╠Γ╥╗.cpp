
#include<iostream>
#include<opencv2/core.hpp>
#include <iostream>  
#include <opencv2/core/core.hpp>  
#include <opencv2/highgui/highgui.hpp> 

using namespace std;
using namespace cv;

int main()
{
	//��ȡͼ����Ϣ
	Mat picture1 = imread("C:\\Users\\Think\\Desktop\\lena.jpg");
	Mat picture2 = imread("C:\\Users\\Think\\Desktop\\nobel.jpg");
	int x_max = 0;
	int y_max = 0;
	x_max = picture2.cols;
	y_max = picture2.rows;

	//�������뾶���������ĵ㵽�ǵľ��룩
	int r_max = 0;
	r_max = int(sqrt(pow(float(x_max / 2), 2) + pow(float(y_max / 2), 2)));
	int t_max = r_max;

	int t = 0;
	int x = 0, y = 0, r = 0;
	float fpss = 20;
	CvSize size = cvSize(408, 408);
	CvVideoWriter* writer = cvCreateVideoWriter("test.avi", CV_FOURCC('M', 'J', 'P', 'G'), fpss, size, true);

	//��֡����ʽȥʵ����Ƶ
	//ʱ����������ֵ�ͼ�ΰ뾶����ϵ
	Mat result;
	result = picture2;
	for (t = 0;t < t_max;t++) {
		for (x = max(0, x_max / 2 - t);x < (x_max / 2 + t, x_max);x++) {
			uchar* data = result.ptr<uchar>(x);
			uchar* p1 = picture1.ptr<uchar>(x);
			for (y = max(0, y_max / 2 - t);y < min(y_max / 2 + t, y_max);y++) {
				r = sqrt(pow(float(x - x_max / 2), 2) + pow(float(y - y_max / 2), 2));
				if (r <= t) {
					data[y * 3] = p1[y * 3];
					data[y * 3 + 1] = p1[y * 3 + 1];
					data[y * 3 + 2] = p1[y * 3 + 2];

				}
			}

		}
		cvWriteFrame(writer, &IplImage(result));

	}


	return 0;
}
