# test.py
import numpy
import time
from numpy import *
from PIL import Image, ImagePalette
import sys
		
def splitarr(arr):
	Rmax = 0
	Rmin = 255
	Gmax = 0
	Gmin = 255
	Bmax = 0
	Bmin = 255
	sorted_arr = numpy.zeros([len(arr)], dtype=[('index', int), ('r', int), ('g', int), ('b', int)])
	for i in range(len(arr)):
		if arr[i][1] > Rmax:
			Rmax = arr[i][1]
		if arr[i][1] < Rmin:
			Rmin = arr[i][1]
		if arr[i][2] > Gmax:
			Gmax = arr[i][2]
		if arr[i][2] < Gmin:
			Gmin = arr[i][2]
		if arr[i][3] > Bmax:
			Bmax = arr[i][3]
		if arr[i][3] < Bmin:
			Bmin = arr[i][3]
	deltaR = Rmax - Rmin
	deltaG = Gmax - Gmin
	deltaB = Bmax - Bmin
	if deltaR == max(deltaR, deltaG, deltaB):
		sorted_arr = numpy.sort(arr, order = 'r')
	elif deltaG == max(deltaR, deltaG, deltaB):
		sorted_arr = numpy.sort(arr, order = 'g')
	else:
		sorted_arr = numpy.sort(arr, order = 'b')
	dest_arr = numpy.array_split(sorted_arr, 2)
	return dest_arr

def median_cut(arr, bit_length):
	if bit_length >= 1:
		splited_arr = splitarr(arr)
		arr1 = median_cut(splited_arr[0], bit_length-1)
		arr2 = median_cut(splited_arr[1], bit_length-1)
		return numpy.append(arr1, arr2)
	else:
		Rsum = 0
		Gsum = 0
		Bsum = 0
		for i in range(len(arr)):
			Rsum += arr[i][1]
			Gsum += arr[i][2]
			Bsum += arr[i][3]
		avg_R = Rsum / len(arr)
		avg_G = Gsum / len(arr)
		avg_B = Bsum / len(arr)
		ar = numpy.zeros([1], dtype=[('r', int), ('g', int), ('b', int)])
		ar[0][0] = avg_R
		ar[0][1] = avg_G
		ar[0][2] = avg_B
		return ar

def arrayToPalette(array, bit_length):
	palette = []
	for i in range(len(array)):
		for j in range(2**(8-bit_length)):
			for k in range(3):
				palette.append(array[i][k])
	return palette
		
def main():
	#if len(sys.argv) != 3:
	#	print("参数数量不正确!")
	#	return 0
	#name = sys.argv[1].split('.', 1)[0]
	start = time.process_time()
	image = Image.open("redapple.jpg")
	width, height = image.size

	imageMatrix = numpy.zeros([width*height], dtype=[('index', int), ('r', int), ('g', int), ('b', int)])

	for i in range(width):
		for j in range(height):
			r, g, b, *_ = image.getpixel((i, j))
			imageMatrix[i*height+j] = (i*height+j, r, g, b)
			
	paletteArray = median_cut(imageMatrix, int(sys.argv[2]))
	
	palette = arrayToPalette(paletteArray, int(sys.argv[2]))
	
	dest = image.copy().convert("P")
	dest.putpalette(palette)
	length = len(paletteArray)
	bits = int(2**(8-int(sys.argv[2])))
	bits3 = 3*bits
	
	
	for i in range(width):
		for j in range(height):
			MinDis = 200000
			index = 0
			pos = i*height+j
			r = imageMatrix[pos]['r']
			g = imageMatrix[pos]['g']
			b = imageMatrix[pos]['b']
			for k in range(length):
				position = k*bits3
				delta_r = r-palette[position]
				delta_g = g-palette[position+1]
				delta_b = b-palette[position+2]
				dis = delta_r*delta_r + delta_g*delta_g + delta_b*delta_b
				if dis < MinDis:
					MinDis = dis
					index = k
			dest.putpixel((i, j), (index*bits))
	
	dest.save('out/' + name + '_' + sys.argv[2] + '.bmp')
	elapsed = (time.process_time() - start)
	print("Time used:", elapsed)
	return 0

main()
