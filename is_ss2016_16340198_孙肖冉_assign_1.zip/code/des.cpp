#include<iostream>
#include <string>
#include <bitset>
#include <fstream>
#include "des.hpp"
using namespace std;


int main(){
	cout << "==================================================" << endl;
	cout << endl;
	cout << "             DATA ENCYTION STANDARD               " << endl;
	cout << endl;
	cout << "==================================================" << endl;
	string test;
	string k;
	while(true){
		cout << "PLEASE ENTER THE *CONTENT* THAT YOU NEED TO ENCRYPT:" << endl;
		cout << "TIP : LENGHT == 8 " <<endl;
		cin >> test;
		if(test.size()!=8){
			cout << "************************************"<<endl;
			cout << "*         SOMETHING WRONG!!!       *"<<endl; 
			cout << "************************************"<<endl;
			
		}else{
			break;
		}
	
	}
	
	while(true){
		cout << "PLEASE ENTER THE *KEY* THAT YOU NEED TO USE:" << endl;
		cout << "TIP : LENGHT == 8 " <<endl;
		cin >> k;
		if(k.size()!=8){
			cout << "************************************"<<endl;
			cout << "*         SOMETHING WRONG!!!       *"<<endl; 
			cout << "************************************"<<endl;
		}else{
			break;
		}
	}
	
	
	bitset<64> plain = charToBitset(test.c_str());
	key = charToBitset(k.c_str());
	// ����16������Կ
	Get_SubKey();
	// ����д�� a.txt
	bitset<64> cipher = encrypt(plain);
	fstream file1;
	file1.open("D://result//encrypt.txt", ios::binary | ios::out);
	file1.write((char*)&cipher, sizeof(cipher));
	file1.close();
//	cout << cipher;

	// ���ļ� a.txt
	bitset<64> temp;
	file1.open("D://result//encrypt.txt", ios::binary | ios::in);
	file1.read((char*)&temp, sizeof(temp));
	file1.close();

	// ���ܣ���д���ļ� b.txt
	bitset<64> tmp = decrypt(temp);
	file1.open("D://result//decrypt.txt", ios::binary | ios::out);
	file1.write((char*)&tmp, sizeof(tmp));
	file1.close();

	

	
	return 0;
}
