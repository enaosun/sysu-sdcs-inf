#include <iostream>
#include "MD5.h"
using namespace std ;


int main() {



    cout << "-----------------------------------------------------------------------------" << endl;
    cout << "-                                 MD5                                       -" << endl;
    cout << "-----------------------------------------------------------------------------" << endl;

		string test = "abcdefghijklmnopqrstuvwxyz" ;
		string flag = "c3fcd3d76192e4007dfb496cca67e13b";
		
        MD5 smaple(test);
        
        
        string result = smaple.Encode();
        cout << "ORIGINAL INFOR: " << test << endl << endl;
        cout << "CORRECT ANSWER: " << flag << endl << endl;
        cout << "FINALLY RESULT: " << result << endl << endl;
        
		if(flag == result){
			cout << "SUCCESSFUL!!!"<<endl;
		}else{
			cout << "FAILED!"<<endl;
		}      
        

    return 0;
}
