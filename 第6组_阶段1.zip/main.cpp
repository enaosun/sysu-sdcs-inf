#include <bits/stdc++.h>
//#include "page.h"
#include "step1.h"
//#include "step3.h"
using namespace std;
#define N 2196017




int main(){
	cout << "*===================================*" << endl;
	cout << "*          the section one          *" << endl;
	cout << "*===================================*" << endl;
	
	string read_file = "glove";
	file_operation(read_file);
	

}
