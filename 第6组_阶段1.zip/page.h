#include <bits/stdc++.h>
using namespace std;
#define dimension 300
#define vector_count 54

class Vector{
	private :
		int vector_id;
		float data[dimension] ;
	public :
		Vector(){
			for(int i = 0 ; i < dimension ; i++){
				data[i] = 0 ;
			}
		}
		
		Vector(Vector* test){
			vector_id = test->get_id();
			for(int i = 0 ; i < dimension ; i++){
				data[i] = test->get_data(i);
			}
		}
		
		int get_id(){
			
			return vector_id;
		}
		
		void set_id(int num){
			vector_id = num;
		}
		
		void set_data(int num1 , float num2){
			data[num1] = num2;
		}
		
		float get_data(int num){
			return data[num];
		}
		


};

class Page{
	private :
		int page_id;
		Vector slot[vector_count];
	 	int check[vector_count];
	public:
		Page(){
			page_id = 0;
			for(int i = 0 ; i < vector_count ; i++){
				check[i] = 0 ;
			}
		
		} 
		Page(int num){
			page_id = num;
			for(int i = 0 ; i < vector_count ; i++){
				check[i] = 0 ;
			}			
		}
		
		void set_page_id(int num){
			page_id = num;
		}
		
		int get_id(){
			return page_id;
		}
		Vector* get_vector(int num){

			return &slot[num];
		}
		
		void set_check(int num){
			check[num] = 1;
		}
		
		int get_check(int num){
			return check[num];
		}
};
