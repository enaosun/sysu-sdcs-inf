#include <bits/stdc++.h>
#include "page.h"
using namespace std;
#define KNN 200
#define TIMES 1000
#define N 60000
#define vector_bits 3140 

class Node{
	private:
		int id;
		float distance;
	public:
		Node(){
			id = 0 ;
			distance = 0 ;
		}
		
		Node(int num1, int num2){
			id = num1;
			distance = num2;
		} 
		
		Node(Node* temp){
			id = temp->get_id();
			distance = temp->get_distance(); 
		}
		
		int get_id(){
			return id;
		}
		
		float get_distance(){
			return distance;
		}
		
		void set_id(int num){
			id = num;
		}
		
		void set_dis(int num){
			distance = num;
		}
		
};

/*get the sub_distance in one dimension*/
float Distance(int num1 , int num2 ){
	return (num1-num2)*(num1-num2);
}

/* get the distance between */
Node* Euclidean(Vector* temp1 , Vector* temp2){
	float result;
	for(int i = 0 ; i < dimension ; i++){
		result+=Distance(temp1->get_data(i),temp2->get_data(i));
	}
	
	result  = sqrt(result);
	Node* node = new Node(temp2->get_id(),result);
	return node; 
}

/*judge which pointer is further*/
int get_max(Node temp[KNN]){
	int index;
	for(int i = 1 ; i < 200 ; i++){
		if(temp[i].get_distance()>=temp[i-1].get_distance()){
			index = i;
		}
	}
	return index;
}
 
