#include <bits/stdc++.h>
#include "page.h"
using namespace std;
#define N 60000 //the total number of vectors
#define SUM 78400 //100d 

/*write the txt into binary
*--@param-- is the pointer of page 
*/

void file_write2(Page* p){
	FILE* fout = NULL;
	int id = p->get_id();
	/*input[] is the path of the page*/
	char input[50];
	strcpy(input,("D:\\DBproject\\pre_process_data\\"+to_string(id)).c_str());
	fout = fopen(input,"wb");

	/**/
	for(int i = 0 ; i < vector_count ; i++){
		int vector_num = p->get_vector(i)->get_id();
		fwrite(&vector_num,sizeof(int),1,fout);
		for(int j = 0 ; j < dimension ; j++){
			float temp = p->get_vector(i)->get_data(j);
			fwrite(&temp,sizeof(float),1,fout);
		}
	}
	
	for(int k = 0 ; k < vector_count ; k++){
		int check_num = p->get_check(k);
		fwrite(&check_num,sizeof(int),1,fout);
	}
	
	cout << "write page" << id << " successful" << endl;
	fclose(fout);
}



bool file_process(string inputname){
	char input[10];
	strcpy(input,inputname.c_str());
  // change from string to char*
	
	FILE* fin = NULL;
	fin = fopen(input,"r");
	// open the input file "mnist" or "glove"

	if(fin==NULL){
		cout << "open fail"<< endl;
		return false;
	}else{
		// read information 
		cout << "open success" << endl;
		int check = 0 ; //¼ÇÂ¼Ò³ÂëÊý 
		int flag = N/vector_count + 1;//¼ÆËãµÃ³öµÄ×ÜÒ³Êý
		int count = 0 ;// ¼ÇÂ¼ÒÑ¶ÁÏòÁ¿Êý
		float sum_vector = 0 ;//¼ÇÂ¼Ã¿¸öÏòÁ¿µÄºÍ¡£ 
		float store[dimension] = {0};
		
		while(check < flag ){	
			if(count == N){
					fclose(fin);
					cout << "read finish" << endl;
					return true;
				}		
			Page* p = new Page(check);// read infor by one page
	
			for(int i = 0 ; i < vector_count ; i++){
				if(count == N){
					fclose(fin);
					cout << "read finish" << endl;
					break;
				}
				
				int id;// ¶ÁÈ¡ÏòÁ¿µÄidÐÅÏ¢
				fscanf(fin,"%d",&id);	
				int slot_num = id-check*vector_count ;
				p->get_vector(slot_num)->set_id(id);
			
				for(int j = 0 ; j < dimension ; j++){
					float temp ;
					fscanf(fin,"%f",&temp);
					sum_vector += temp;
					store[j] = temp; 
					
					
				}
				
				for(int k = 0 ; k < dimension ; k++){
					float temp1;
					if(store[k] != 0 ){
							temp1 = store[k]*((float)SUM/sum_vector);
					}else{
						temp1 = 0 ;
					}
					p->get_vector(slot_num)->set_data(k,temp1);
				}
				count++;
				p->set_check(slot_num);
			}
			
		
			file_write2(p);
			check++;		
			
			 
		} 
		return true;
	}
	
	
}



 
