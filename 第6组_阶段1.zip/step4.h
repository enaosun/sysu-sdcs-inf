#include <bits/stdc++.h>
#include "node.h"
using namespace std;

#define bytes 3140

Vector* get_test(int random ){


		
		int page_num = random/vector_count;//��������ҳ��
		 
		string address = "D:\\database\\processdata\\"+to_string(page_num);
		char input[50];
		strcpy(input,address.c_str());
		FILE* fin = NULL;
		fin = fopen(input,"rb");
		
		Vector* temp = new Vector();
		
		int slot_num = random - vector_count*page_num;
		fseek(fin,slot_num*bytes,0);
		int* num = (int*)malloc(sizeof(int));
		fread(num,sizeof(int),1,fin);
		temp->set_id(*num);
		
		for(int i = 0 ; i < dimension ; i++){
			float* shu = (float*)malloc(sizeof(float));
			fread(shu,sizeof(float),1,fin);
			temp->set_data(i,*shu);
		}
		
		rewind(fin);
		return temp;

}




void step4(){
	Node store[KNN];

	int flag = 1 ;
	clock_t start,finish;
    double totaltime;
    start=clock();
	
	while(flag <= TIMES){
		srand((unsigned)time(NULL));
		int random  = rand()%N ; //���������
		Vector* test = new Vector( get_test(random));

		for(int i = 0 ; i < KNN ; i++){
			Vector* temp = new Vector(get_test(i));
			Node* temp1 = new Node(Euclidean(test,temp));
			store[i].set_dis(temp1->get_distance());
			store[i].set_id(temp->get_id());
		}
	
		
		for(int i = KNN ; i < N ; i++){
			
			Vector* zan = new Vector(get_test(i));
		
			Node* temp2 = new Node(Euclidean(test,zan));
			int compare = get_max(store);
			if(temp2->get_distance()<store[compare].get_distance()){
				store[compare].set_dis(temp2->get_distance());
				store[compare].set_id(temp2->get_id());
			}
	
		}


	
	
		
	}
	
	finish=clock();
   	totaltime=(double)(finish-start)/CLOCKS_PER_SEC;
   	cout << "the total time is " << totaltime << "(s)" <<endl;
	cout << "compare finish" << endl;
	
}



