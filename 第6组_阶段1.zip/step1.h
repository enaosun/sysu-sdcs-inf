#include <bits/stdc++.h>
#include "page.h"
using namespace std;
#define N 2196017

/*write the txt file into binary
*--@param-- is the pointer of the page
*/
void file_write(Page* p){

	FILE* fout = NULL;
	int id = p->get_id();
	/*input[] is the path of the page*/
	char input[50];
	strcpy(input,("D:\\DBproject\\original_data\\glove_data\\"+to_string(id)).c_str());
	fout = fopen(input,"wb");

	/*loop write the binary vectors into fout*/
	for(int i = 0 ; i < vector_count ; i++){
		int vector_num = p->get_vector(i)->get_id();
		fwrite(&vector_num,sizeof(int),1,fout);
		for(int j = 0 ; j < dimension ; j++){
			float temp = p->get_vector(i)->get_data(j);
			fwrite(&temp,sizeof(float),1,fout);
		}
	}
	
	/*loop write the binary list on the bottom*/
	for(int k = 0 ; k < vector_count ; k++){
		int check_num = p->get_check(k);
		fwrite(&check_num,sizeof(int),1,fout);
	}
	
	/*show the accomplishment of writing one page*/
	cout << "write page" << id << " successful" << endl;
	fclose(fout);
}


/*
*function to read pages
*--@param--is the data set, 'mnist', or 'glove'
*/
bool file_operation(string inputname){
	/*turn string into char* */
	/*open the */
	FILE* fin = NULL;
	char input[10];
	strcpy(input,inputname.c_str());
	fin = fopen(input,"r");

	if(fin==NULL){
		cout << "open fail"<< endl;
		return false;
	}
	else{
		/* read the txt file */
		cout << "open success" << endl;
		int check = 0 ; // the page number reading currently
		int flag = N/vector_count + 1; // the total quantity + 1 of files that should read 
		int count = 0 ;// the number of vectors that has read so far

		/*loop read txt to buffer*/
		while(check < flag ){	

			/*stop the file if pages are full*/
			if(count == N){
					fclose(fin);
					cout << "read finish" << endl;
					return true;
			}		

			/*if pages are not full, start a page and read*/
			Page* p = new Page(check);
			/*loop to read the vectors into page */
			for(int i = 0 ; i < vector_count ; i++){
				
				/*if vectors are all read, stop reading */
				if(count == N){
					fclose(fin);
					cout << "read finish" << endl;
					break;
				}
				
				/*if vectors not all read, read vectors still*/
				int id; 
				fscanf(fin,"%d",&id);	
				int slot_num = id - check * vector_count ;
				p->get_vector(slot_num)->set_id(id);
				
				/*read datad[]*/
				for(int j = 0 ; j < dimension ; j++){
					float temp ;
					fscanf(fin,"%f",&temp);
					p->get_vector(slot_num)->set_data(j,temp);
				}
				count++;
				/*set value to the list on the bottom*/
				p->set_check(slot_num);
			}
			
			/*write the page to a binary file*/
			file_write(p);
			
			check++;		
			
			 
		} 
		return true;
	}
	
	
}



 
