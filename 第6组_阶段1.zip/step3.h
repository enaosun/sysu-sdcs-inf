#include <bits/stdc++.h>
#include "node.h"
using namespace std;



Vector* get_test(string inputname){

		srand((unsigned)time(NULL));
		int random  = rand()%N ; //���������
		long  offset = random*vector_bits;//����ƫ���� 
	
		
		char input[10];
		strcpy(input,inputname.c_str());
		FILE* fin = NULL;
		fin = fopen(input,"r");
		
		for(int i = 0 ; i < random  ; i++){
			int id;
			
			fscanf(fin,"%d",&id);

			for(int j = 0 ; j < dimension ; j++){
				float num;
				fscanf(fin,"%f",&num);
			}

		}
		
		Vector* test = new Vector();
		
		int test_id;
		fscanf(fin,"%d",&test_id);

		for(int k = 0 ; k < dimension ; k++){
			float test_num;
			fscanf(fin,"%f",&test_num);
			test->set_data(k,test_num);
		}

		fclose(fin);
	return test;
}



void step3(string inputname){
	Node store[KNN];

	int flag = 1 ;
	
	clock_t start,finish;
    double totaltime;
    start=clock();

                 

  
	while(flag <= TIMES){
		
	
		
		Vector* test = new Vector( get_test(inputname));
		char input[10];
		strcpy(input,inputname.c_str());
		FILE* fin = NULL;
		fin = fopen(input,"r");
		

		Vector* temp = new Vector();
		for(int i = 0 ; i < KNN ; i++){
			int id ;
			fscanf(fin,"%d",&id);
			//cout << "point2";
			temp->set_id(id);
			for(int j = 0 ; j < dimension ; j++){
				float num;
				fscanf(fin,"%f",&num);
				temp->set_data(i,num);
			} 
			Node* temp1 = new Node(Euclidean(test,temp));
			store[i].set_dis(temp1->get_distance());
			store[i].set_id(temp->get_id());
		}
	//	cout << "point3"<< endl;
		
		for(int i = KNN ; i < N ; i++){
			int id ;
			fscanf(fin,"%d",&id);
			temp->set_id(id);
			for(int j = 0 ; j < dimension ; j++){
				float num;
				fscanf(fin,"%f",&num);
				temp->set_data(j,num);
			} 
		 
			Node* temp2 = new Node(Euclidean(test,temp));
			int compare = get_max(store);
			if(temp2->get_distance()<store[compare].get_distance()){
				store[compare].set_dis(temp2->get_distance());
				store[compare].set_id(temp2->get_id()); 
			}
		}
		//	cout << id << endl;
		
	//	cout << "point4";
			fclose(fin);

		
		
	//	break;
		
	//	break;
		flag++;
	}
	
	
	finish=clock();
   	totaltime=(double)(finish-start)/CLOCKS_PER_SEC;
   	cout << "the total time is " << totaltime << "(s)"<< endl;
	cout << "compare finish" << endl;
}



