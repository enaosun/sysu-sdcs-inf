#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h> 
#include<string.h> 

#define v_MAX 60000
#define v_per_page 20
#define dimension 784
#define buffer_page_max 30

int p_MAX = v_MAX / v_per_page + (v_MAX % v_per_page? 1:0);
int v_size = dimension + 1;
int p_size = v_per_page * (dimension + 1 + 1) + 1;


//double product = 100 * dimension;


bool file_translate(const char* file){
 	
	
 	// prompt to make sure the relevant info, sure--'y',and quit cmd with 'n'
	puts("Are you sure that: ");
	printf("file %s has:\n  %d vecors\n  %d dimensions\n  %d vectors per page\n",
			file ,v_MAX, dimension, v_per_page);
	printf("buffer process has:\n  %d pages in buffer\n  %d pages totally\n  %d p_size\n  %d v_size\ny/n?: ",
			buffer_page_max, p_MAX, p_size, v_size);
	if(getchar() == 'n') return false;
	
	//open the infile with a transform of path name from string to char[], and check if fopen is correct
	char fname[30];
	strcpy(fname,"D:\\DBproject\\");
	strcat(fname,file);
	printf("fin is %s\n",fname);
	FILE* fin = fopen(fname,"rb");
	if(ferror(fin)){
		printf("Error opening fin.\n");
		return false;
	}
	
	//open the outfile also with a transform from string to char[]
	char pname[100];
	strcpy(pname,"D:\\DBproject\\original_data\\");
	//to choose if it is mnist or glove 
	if(file[0] == 'g') strcat(pname, "glove_data\\ori_bin_glove");
	else strcat(pname, "mnist_data\\ori_bin_mnist");
	printf("fout is :%s\n",pname); 
	
	FILE* fout = fopen(pname, "wb");
	if(ferror(fout)){
		printf("Error opening fout.\n");
		return false;
	} 
	
	
	
	int v_done_total = 0; // total numbers of vectors that have written 
	int p_done_total = 0; //total numbers of pages that have written
	
	//printf("haha\n");
	//loop 50 pages/loop
	
	float buffer_pages[buffer_page_max][p_size];// = {0};
	for(int i = 0; i < buffer_page_max; i++){
		for(int j = 0; j < p_size; j++){
			buffer_pages[i][j] = 0;
		}
	}
	
		
	/*read 50 pages, if it is the last page then init to 0 and then scan*/
	// 50 pages / loop
	for(int i = 0; i < buffer_page_max ; i++){
		//printf("%d\n",i);
		//the last page of the data set
		if(p_done_total == p_MAX - 1){
			puts("in the last page");
			//initiate this page
			for(int j = 0; j < p_size; j++){
					buffer_pages[i][j] = 0;
			}

			int have_not_done = v_MAX - v_done_total;
			
			printf("p_total = %d, have not done = %d\n", p_done_total,have_not_done);
			
			//read
			for(int v = 0; v < have_not_done; v++){
				int num;
				fscanf(fin, "%d", &num);
				//printf("\n num = %d\n", num);
				buffer_pages[i][v*v_size] = (float)num;
				
				printf("id =%f\n", buffer_pages[i][v*v_size]);
				for(int d = 1; d <= dimension; d++){
					fscanf(fin, "%f", &buffer_pages[i][v*v_size + d]);
				}
		
				v_done_total ++;
				
				
			}
			
			buffer_pages[i][p_size - 1] = have_not_done;
			for(int check_num = 0; check_num < have_not_done; check_num++){
				buffer_pages[i][v_size*v_per_page + check_num] = 1.0;
				//printf("check %d = %f\n", check_num, buffer_pages[i][v_size*v_per_page+check_num]);
			}
			p_done_total++;	
			printf("bytes sizeof buffer_pages is %d\n", (i + 1)*p_size  );
			printf("last time have write %d pages\n",i+1);
			if(fwrite(buffer_pages, (i + 1)*p_size*4, 1, fout) != 1){
				printf("Error fwrite.\n");
				return false;
			}
			break;
		}

		//read
		//v_per_page vectors/ loop
		for(int v = 0; v < v_per_page; v++){
			
			int num;
			fscanf(fin, "%d", &num);
			//printf("\n num = %d\n", num);
			buffer_pages[i][v*v_size] = (float)num;
			//printf("id =%f\n", buffer_pages[i][v*v_size]);
			//	puts("datad = ");
			for(int d = 1; d <= dimension; d++){
				fscanf(fin, "%f", &buffer_pages[i][v*v_size + d]);
				//printf("  %f", buffer_pages[i][v*v_size + d]);
			}

			v_done_total ++;
		}
		
		//set check
		buffer_pages[i][p_size - 1] = v_per_page;
		for(int check_num = 0; check_num < v_per_page; check_num++){
			buffer_pages[i][v_size*v_per_page + check_num] = 1.0;
			//printf("check %d = %f\n", check_num, buffer_pages[i][v_size*v_per_page+check_num]);
		}
		
		p_done_total++;

		if(i == buffer_page_max - 1){
			//printf("bytes sizeof buffer_pages is %d\n", sizeof(buffer_pages) /4  );
			if(fwrite(buffer_pages, sizeof(buffer_pages), 1, fout) != 1){
				printf("Error fwrite.\n");
				return false;
			}
			i = 0;
		}

	}
		
	
	fclose(fin);
	fclose(fout);
	return true;
}

