#include<stdio.h>
#include<stdlib.h>

#define v_MAX 60000
#define v_per_page 20
#define dimension 784



int check[dimension];


size_t v_size = sizeof(int) + sizeof(float)*dimension;
size_t check_size = sizeof(int) * v_per_page; 

double product = 100 * dimension;


