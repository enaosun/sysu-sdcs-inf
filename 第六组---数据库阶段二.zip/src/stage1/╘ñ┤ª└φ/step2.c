#include<stdio.h>
#include<time.h> 
#include<stdlib.h>
#include"pre_process.h"
int main(){
	
	clock_t time = clock();
	
	bool is_successful = pre_process("mnist_data");
	if(is_successful)
		printf("Pre process successfully!\n");
	
	else
		printf("Pre process failed.\n");
	
	time = (clock() - time)/CLOCKS_PER_SEC; 
	printf("time is %ds\n", time);
	system("pause");
	
}
