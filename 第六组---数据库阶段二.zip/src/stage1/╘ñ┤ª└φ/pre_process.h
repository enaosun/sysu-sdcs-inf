#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h> 
#include<string.h> 

#define v_MAX 60000
#define v_per_page 20
#define dimension 784
#define buffer_page_max 10

int p_MAX = v_MAX / v_per_page + (v_MAX % v_per_page ? 1:0);
int v_size = dimension + 1;
int p_size = v_per_page * (dimension + 1 + 1) + 1;
int check_size = dimension + 1;

double product = 100 * dimension;


bool pre_process(const char* file){
 	int process_time = p_MAX / buffer_page_max + (p_MAX % buffer_page_max ? 1:0);
	
 	// prompt to make sure the relevant info, sure--'y',and quit cmd with 'n'
	puts("Are you sure that: ");
	printf("file %s has:\n  %d vectors\n  %d dimensions\n  %d vectors per page\n",
			file ,v_MAX, dimension, v_per_page);
	printf("buffer process has:\n  %d pages in buffer\n  %d pages totally\n  %d p_size\n  %d v_size\n ",
			buffer_page_max, p_MAX, p_size, v_size);
	printf("process times is %d\n?y/n:  ", process_time);
	if(getchar() == 'n') return false;
	
	//open the infile with a transform of path name from string to char[], and check if fopen is correct
	char fname[100];
	strcpy(fname,"D:\\DBproject\\original_data\\");
	if(file[0] == 'g') strcat(fname, "glove_data\\ori_bin_glove");
	else strcat(fname, "mnist_data\\ori_bin_mnist");
	printf("fin is %s\n",fname);
	FILE* fin = fopen(fname,"rb");
	if(ferror(fin)){
		printf("Error opening fin.\n");
		return false;
	}
	
	//open the outfile also with a transform from string to char[]
	char pname[100];
	strcpy(pname,"D:\\DBproject\\pre_process_data\\");
	//to choose if it is mnist or glove 
	if(file[0] == 'g') strcat(pname, "glove_data\\pre_process_glove");
	else strcat(pname, "mnist_data\\pre_process_mnist");
	printf("fout is :%s\n",pname); 
	FILE* fout = fopen(pname, "wb");
	if(ferror(fout)){
		printf("Error opening fout.\n");
		return false;
	} 
	
	
	int v_done_total = 0; // total numbers of vectors that have written 
	int p_done_total = 0; //total numbers of pages that have written
	
	float buffer_pages[buffer_page_max][p_size];

	for(int i = 0; i < buffer_page_max; i++){
		for(int j = 0; j < p_size; j++){
			buffer_pages[i][j] = 0;
		}
	}
	
	
	/*read 50 pages/loop, and process the datad[]*/
	//normal case, not the last page
	
	
	for(int i = 0; i < process_time - 1; i++){

		fread(buffer_pages,sizeof(buffer_pages),1,fin);
		
		// process p pages / loop
		for(int p = 0; p < buffer_page_max; p++){
		
			//process v_per_page vectors / loop
			for(int v = 0; v < v_per_page; v++){
				
			
				float sum = 0.0;
				for(int d = 1; d <= dimension; d++){
					sum += buffer_pages[p][v * v_size + d];
				}
				
				float xishu = product / sum;

				for(int d = 1; d <= dimension; d++){
					
					buffer_pages[p][v*v_size + d] *= xishu; 
					
				}

				v_done_total ++;
			}

			p_done_total ++;
		}

		if(fwrite(buffer_pages, sizeof(buffer_pages), 1, fout) != 1){
			printf("Error fwrite.\n");
			return false;
		}
	}
	
	/*last process*/
	//there are p_MAX - p_done_total pages to write
	int p_have_not_done = p_MAX - p_done_total;
	int v_have_not_done = v_MAX - v_per_page*(p_MAX-1);
	fread(buffer_pages, p_have_not_done * p_size * 4, 1, fin);
	
	for(int p = 0; p < p_have_not_done; p++){
		
			//process v_per_page vectors / loop
		for(int v = 0; v < v_have_not_done; v++){
			
			float sum = 0.0;
			for(int d = 1; d <= dimension; d++){
				sum += buffer_pages[p][v * v_size + d];
			}
				
			float xishu = product / sum;

			for(int d = 1; d <= dimension; d++){
				buffer_pages[p][v*v_size + d] *= xishu; 
				
			}

			v_done_total ++;
		}

		p_done_total ++;
	}

	if(fwrite(buffer_pages, p_have_not_done * p_size * 4, 1, fout) != 1){
		printf("Error fwrite.\n");
		return false;
	}

	fclose(fin);
	fclose(fout);
	return true;
}

