#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h> 
#include<string.h> 
#include<time.h> 
#include<math.h>

#define v_range 10000
#define v_per_page 20
#define dimension 784
#define buffer_page_max 20
#define random_time 1000
#define knn 200
int p_range = v_range / v_per_page + (v_range % v_per_page ? 1:0);
int v_size = dimension + 1;
int p_size = v_per_page * (dimension + 1 + 1) + 1;
int check_size = dimension + 1;

struct Node{
	float id;
	float distance;
};
int cmp (const void* a, const void* b);
bool knn_search(const char* file);

int main(){
	clock_t time = clock();
	
	bool is_find = knn_search("ori_bin_mnist");
	if(is_find){
		puts("Search successfully!\n");
		
	}
	else 
		puts("Search failed.\n");
	
	time = clock() - time;
	time /= CLOCKS_PER_SEC;
	printf("cmd exsting time is %ds\n", time);
}

int cmp (const void* a, const void* b){
   return ((*(struct Node *)a).distance - (*(struct Node *)b).distance);
}

bool knn_search(const char* file){
 	int process_time = p_range / buffer_page_max + (p_range % buffer_page_max ? 1:0);
	
 	// prompt to make sure the relevant info, sure--'y',and quit cmd with 'n'
	puts("Are you sure that: ");
	printf("search from %s and :\n  %d range of vectors\n  %d dimensions\n  %d vectors per page\n",
			file ,v_range, dimension, v_per_page);
	printf("buffer process has:\n  %d pages in buffer\n  %d pages totally\n  %d p_size\n  %d v_size\n ",
			buffer_page_max, p_range, p_size, v_size);
	printf("random times is\n  %d\n", random_time);
	printf("and process times/search is %d\n?y/n:  ", process_time);
	
	if(getchar() == 'n') return false;


	//open the infile with a transform of path name from string to char[], and check if fopen is correct
	char fname[100];
	
	if(file[0] == 'o') {
		strcpy(fname,"D:\\DBproject\\original_data\\mnist_data\\ori_bin_mnist");
	}
	else {
		strcpy(fname,"D:\\DBproject\\pre_process_data\\mnist_data\\pre_process_mnist");
	}
	printf("fin is %s\n",fname);
	FILE* fin = fopen(fname,"rb");
	if(ferror(fin)){
		printf("Error opening fin.\n");
		return false;
	}

	/*this is the buffer array*/
	float buffer_pages[buffer_page_max][p_size];
	
	for(int i = 0; i < buffer_page_max; i++){
		for(int j = 0; j < p_size; j++){
			buffer_pages[i][j] = 0;
		}
	}

	/*start search*/
	srand((unsigned)time(NULL));

 	for(int r = 0; r < random_time; r++){
 		/*rand a vector*/
 		struct Node store[v_range];
 		int random_id = rand() % v_range ;
 		printf("rand id = %d\n", random_id);

 		/*get the info of one random vector*/
 		int mypage = (random_id + 1)/ v_per_page + ((random_id + 1) % v_per_page ? 1 : 0) ;
 		int mybuffer_turn = mypage / buffer_page_max + (mypage % buffer_page_max? 1 : 0);
 		int mypage_in_buffer = mypage % buffer_page_max - 1;//because the index is from 0-buffer_page_max - 1
 		int myid_in_buffer = random_id % v_per_page;
 		printf("page number = %d  needs buffer turn : %d  pagen_umber_in_buffer = %d  id_in_buffer = %d \n",
 			mypage, mybuffer_turn, mypage_in_buffer, myid_in_buffer);
 		puts("y/n?  :");
 		if(getchar() == 'n') return false;
 		float myvector[dimension + 1] = {0};
 		for(int i = 0; i < mybuffer_turn; i ++){
 			fread(buffer_pages,sizeof(buffer_pages),1,fin);
 			
 		}
 		float myid = buffer_pages[mypage_in_buffer][myid_in_buffer * v_size];
 		printf("find id = %f\n", myid);
 		float mydatad[dimension] = {0};
 		for(int d = 1; d <= dimension; d++){
 			mydatad[d-1] = buffer_pages[mypage_in_buffer][myid_in_buffer * v_size + d];
 			printf(" %f   ", mydatad[d-1]); 
 		} 


 		/*search from the beginning*/
 		fseek(fin, 0, SEEK_SET);
 		/*normal cases search*/
 		int v_search_total = 0; // total numbers of vectors that have searched
		int p_search_total = 0; //total numbers of pages that have searched
 		for(int i = 0; i < process_time - 1; i++){


 		
			fread(buffer_pages,sizeof(buffer_pages),1,fin);
			
			// search p pages / loop
			for(int p = 0; p < buffer_page_max; p++){
			
				//search v_per_page vectors / loop
				for(int v = 0; v < v_per_page; v++){
					
					store[v_search_total].id = buffer_pages[p][v*v_size];
					printf("finding vector %f     ",buffer_pages[p][v*v_size]);
					float distance_add_product = 0.0;
					for(int d = 1; d <= dimension; d ++){
						distance_add_product += (float)pow((mydatad[d-1] - buffer_pages[p][v*v_size + d]), 2); 
					} 

					store[v_search_total].distance = distance_add_product;
					v_search_total ++;
				}

				p_search_total ++;
			}

		}

		/*last process*/
		//there are p_range - p_search_total pages to write
		int p_have_not_done = p_range - p_search_total;
		int v_have_not_done = v_range - v_per_page*(p_range-1);
		fread(buffer_pages, p_have_not_done * p_size * 4, 1, fin);
		
		for(int p = 0; p < p_have_not_done; p++){
			
				//process v_per_page vectors / loop
			for(int v = 0; v < v_have_not_done; v++){
			
				store[v_search_total].id = buffer_pages[p][v*v_size];
				printf("finding vector %f     ",buffer_pages[p][v*v_size]);
				float distance_add_product = 0.0;
				for(int d = 1; d <= dimension; d ++){
					distance_add_product += (float)pow((mydatad[d-1] - buffer_pages[p][v*v_size + d]), 2); 
				} 
				store[v_search_total].distance = distance_add_product;
				v_search_total ++;
			}
			p_search_total ++;
		}
		
		
		qsort(store,v_range,sizeof(store[0]),cmp);
	 	puts("\nresults:\n");
	 	for(int v = 0; v < knn; v ++){
	 		printf("id = %f  distance = %f\n", store[v].id, store[v].distance);
		 }
 	}

 	

	fclose(fin);
	
	return true;
}


