//#include <bits/stdc++.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>


struct Node{
	float id;
	float distance;
};

struct Node store[2];


int cmp (const void* a, const void* b){
   return ((*(struct Node *)a).distance - (*(struct Node *)b).distance);
}


int main(){
	store[0].distance = 2;
	store[0].id = 0;
	
	store[1].distance = 1;
	store[1].id = 1;
	qsort(store,2,sizeof(store[0]),cmp);
	
	printf("NO.0 dis %lf",store[0].id);
	
	
}
