#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>

/*===========IMPORTANT!!============ 
* in this file the pages in buffer is doubled so remenber to:
* make buffer_page_max 1/2
*/
#define v_MAX 60000
#define v_per_page 20
#define dimension 784
#define buffer_page_max 15

#define K 32
#define Gauss_v_per_page 481


int p_MAX = v_MAX / v_per_page + (v_MAX % v_per_page ? 1:0);
int v_size = dimension + 1;
int p_size = v_per_page * (dimension + 1 + 1) + 1;
int check_size = dimension + 1;

int Gauss_p_MAX = v_MAX / Gauss_v_per_page + (v_MAX % Gauss_v_per_page ? 1:0);
int Gauss_v_size = K + 1;
int Gauss_p_size = Gauss_v_per_page * (K + 1 + 1) + 1;
int Gauss_check_size = K + 1;
bool Gauss(const char* file);

int main()
{
	//to send parameter to "mnist" or "glove"
	bool is_successful = Gauss("mnist");
	if(is_successful){
		puts("Gauss reflect seccessful!\n");

	}
	else {
		puts("Gauss reflect failed.\n");
	}
	return 0;
}


bool Gauss(const char* file){
	int read_times = p_MAX / buffer_page_max + (p_MAX % buffer_page_max ? 1:0);
	// prompt to make sure the relevant info, sure--'y',and quit cmd with 'n'
	puts("Are you sure that: ");
	printf(" file %s has:\n  %d vectors\n  %d dimensions\n  %d vectors per page\n",
			file ,v_MAX, dimension, v_per_page);
	printf(" fread times is %d\n", read_times);
	printf(" buffer read has:\n  %d pages of each knid in buffer\n", buffer_page_max);
	printf(" for reflection of %s\n",file);
	printf("  %d pages\n  %d vectors/page\n  %d /vector size\n  %d /page size\n?y/n:  ",Gauss_p_MAX, Gauss_v_per_page, Gauss_v_size, Gauss_p_size);
	
	if(getchar() == 'n') return false;

	/*get the Gauss Matrix into buffer*/
	char matrixname[100];
	strcpy(matrixname, "D:\\DBproject\\Gauss_reflect\\mnist_Gauss_Matrix");
	FILE* fmatrix = fopen(matrixname, "rb");
	if(ferror(fmatrix)){
		printf("Error opening fout.\n");
		return false;
	} 

	float Gauss_Matrix[K][dimension];
	fread(Gauss_Matrix, sizeof(Gauss_Matrix), 1, fmatrix);

	fclose(fmatrix);


	/*open the fin and fout*/
	char finname[100];
	strcpy(finname, "D:\\DBproject\\pre_process_data");
	if(file[0] == 'm'){
		strcat(finname,"\\mnist_data\\pre_process_mnist");
	}
	else{
		strcat(finname,"\\glove_data\\pre_process_glove");
	}
	FILE* fin = fopen(finname, "rb");
	if(ferror(fin)){
	
		printf("Error opening fout.\n");
		return false;
	} 
	char foutname[100];
	strcpy(foutname, "D:\\DBproject\\Gauss_reflect\\");
	if(file[0] == 'm'){
		strcat(foutname,"mnist_Gauss_Reflect");
	}
	else{
		strcat(foutname,"glove_Gauss_Reflect");
	}
	
	FILE* fout = fopen(foutname, "wb");
	if(ferror(fout)){
		printf("Error opening fout.\n");
		return false;
	} 

	printf("fin = %s\nfout = %s\n",finname, foutname );

	/*reflect the vectors*/
	int v_read_total = 0; // total numbers of vectors that have read into buffer
	int p_read_total = 0; //total numbers of pages that have read into buffer
	
	int p_write_total = 0;// total numbers of pages that have write to the reflection file
	int write_pid = 0; // index for page id in the buffer
	int write_vid = 0; //index for vector id in the buffer 

	/*I will read the pre_process data into buffer_pages, now initiate the buffer_pages*/
	float buffer_pages[buffer_page_max][p_size];
	for(int i = 0; i < buffer_page_max; i++){
		for(int j = 0; j < p_size; j++){
			buffer_pages[i][j] = 0;
		}
	}

	/*I will write the reflection into reflect_pages, now initiate the reflect_pages*/
	float reflect_pages[buffer_page_max][Gauss_p_size];
	for(int i = 0; i < buffer_page_max; i++){
		for(int j = 0; j < Gauss_p_size; j++){
			reflect_pages[i][j] = 0;
		}
	}
	
//fread(&buffer_pages[p],sizeof(buffer_pages[p]),1,fin);


	//buffer_page_max / loop in the normal case
	for(int i = 0; i < read_times ; i ++)
	{
		
		for(int p = 0; p < buffer_page_max ; p ++){
			fread(buffer_pages[p], p_size * 4, 1,  fin);
			if(i !=0 && buffer_pages[p][0] == 0.0){
				fread(buffer_pages[p], p_size * 4, 1, fin);
			}
			printf("page %d's first vid = %f\n", i * buffer_page_max + p, buffer_pages[p][0]);
		}
		for(int p = 0; p < buffer_page_max; p ++)
		{
			
			for(int v = 0; v < v_per_page; v ++)
			{
				//printf("v_read_total = %d\n", v_read_total);
				//if page full, set check , pid++, page total++, if need to write, 
				if(write_vid == Gauss_v_per_page)
				{
					//set check
					for(int check = 0; check < K; check ++)
					{
						reflect_pages[write_pid][Gauss_v_size*Gauss_v_per_page + check] = 1.0;
					}
					reflect_pages[write_pid][Gauss_p_size - 1] = Gauss_v_per_page;
					
					write_vid = 0;
					write_pid ++;
					p_write_total++;
					if (write_pid == buffer_page_max )
					{
						write_pid = 0;
						//and don't need to cover reflect_pages[][] with “0”
						if(fwrite(reflect_pages, sizeof(reflect_pages), 1, fout) != 1){
							puts("Fwrite error.\n");
							return false;
						}
					}
	
				}

				
				reflect_pages[write_pid][write_vid * Gauss_v_size] = buffer_pages[p][v*v_size]; //set id
				printf("reflect  id ========== %f\n", reflect_pages[write_pid][write_vid * Gauss_v_size]);
				for(int write_did = 1; write_did <= K; write_did++ ){

					for(int d = 1; d < dimension; d++){

					 	reflect_pages[write_pid][write_vid * Gauss_v_size + write_did] += buffer_pages[p][v*v_size + d] * Gauss_Matrix[write_did - 1][d-1];
					}

				}
				write_vid ++;
				v_read_total++;
				 
			}

			p_read_total++;
		}
	}

/*	printf("p_read_total = %d\n", p_read_total);
	//for the time to reflect the left pages in pre_process file
	int p_have_not_read = p_MAX - p_read_total;
	printf("p_have_not_read = %d\n", p_have_not_read);

	int v_have_not_read = v_MAX - v_per_page*(p_MAX-1);
	//init first then set value
	for(int i = 0; i < buffer_page_max; i++){
		for(int j = 0; j < Gauss_p_size; j++){
			reflect_pages[i][j] = 0;
		}
	}

	 

	fread(buffer_pages, sizeof(buffer_pages), 1, fin);
	printf("======================vid = %f\n", buffer_pages[0][0]);
	for(int p = 0; p < p_have_not_read; p ++)
	{
		for(int v = 0; v < v_per_page; v ++)
		{

			if(write_vid == Gauss_v_per_page)
			{
				//set check
				for(int check = 0; check < K; check ++)
				{
					reflect_pages[write_pid][Gauss_v_size*Gauss_v_per_page + check] = 1.0;
				}
				reflect_pages[write_pid][Gauss_p_size - 1] = Gauss_v_per_page;
				
				write_vid = 0;
				write_pid ++;
				p_write_total++;
				if (write_pid == buffer_page_max)
				{
					write_pid = 0;
					//and don't need to cover reflect_pages[][] with “0”
					if(fwrite(reflect_pages, sizeof(reflect_pages), 1, fout) != 1)
					{
						puts("Fwrite error.\n");
						return false;
					}
				
				}
	
			}

			reflect_pages[write_pid][write_vid * Gauss_v_size] = buffer_pages[p][v*v_size]; //set id
			printf("\nreflect id = %f\n", reflect_pages[write_pid][write_vid * Gauss_v_size]);
				
			for(int write_did = 1; write_did <= K; write_did++ )
			{
				for(int d = 1; d < dimension; d++)
				{

				 	reflect_pages[write_pid][write_vid * Gauss_v_size + write_did] += buffer_pages[p][v*v_size + d] * Gauss_Matrix[write_did - 1][d-1];
				}

				//printf("[%d] = %f   ", write_did, reflect_pages[write_pid][write_vid * Gauss_v_size + write_did]);
			}

			write_vid++;
			v_read_total++;


			if(v_read_total == v_MAX)
			{
				for(int check = 0; check < write_vid + 1; check ++)
				{
					reflect_pages[write_pid][Gauss_v_size*Gauss_v_per_page + check] = 1.0;
					//printf("check[%d] = %f\n", check, reflect_pages[write_pid][Gauss_v_size*Gauss_v_per_page + check]);
				}
				reflect_pages[write_pid][Gauss_p_size - 1] = write_vid+1;
				if(fwrite(reflect_pages, sizeof(reflect_pages), 1, fout)!= 1)
				{
					puts("Fwrite error.\n");
					return false;
				}//and don't need to cover reflect_pages[][] with “0”
			}
				
		}

		p_read_total++;
	}*/


	fclose(fin);
	fclose(fout);

	
}
