#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>


#define dimension 784
#define PI 3.1415926
#define K 32

bool Gauss_Matrix();

int main()
{
	int is_successful = Gauss_Matrix("mnist");
	if(!is_successful){
		printf("Error forming.\n");
	}
	else
		printf("Forming successfully!\n");

	return 0;
}

bool Gauss_Matrix(const char* file){
	char fname[100];
	strcpy(fname, "D:\\DBproject\\Gauss_reflect\\mnist_Gauss_Matrix");
	FILE* fout = fopen(fname, "w+b");
	if(ferror(fout)){
		printf("Error opening fout.\n");
		return false;
	} 


	float Gauss_Matrix[K][dimension];
	for(int i = 0 ; i < K; i++){
	//	float store[K][dimension];
		for(int j = 0 ; j  < dimension ; j++){
			float u1 = rand()%100/(double)101;
			while(u1 == 0.0){
				u1 = rand()%100/(double)101;
			}
			float u2 = rand()%100/(double)101;
			//printf("%f\n",u1);
			//printf("%f\n",u2);
			float z = (sqrt(-2*log(u1))*cos(2*PI*u2));
			printf("%f ",z);
			Gauss_Matrix[i][j] = z;
		}
		puts("\n");
	
	}

	if(fwrite(Gauss_Matrix, sizeof(Gauss_Matrix), 1, fout) != 1){
		printf("Error write.\n");
		fclose(fout);
		return false;
	}
	fclose(fout);
	return true;
   
}	

