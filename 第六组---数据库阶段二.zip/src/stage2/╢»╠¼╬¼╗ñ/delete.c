#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h> 
#include<string.h> 
#include<time.h> 

#define v_MAX 60000
#define v_per_page 20
#define dimension 784
#define buffer_page_max 10 //please make 3000%buffer_page_max = 0

int p_MAX = v_MAX / v_per_page + (v_MAX % v_per_page ? 1:0);
int v_size = dimension + 1;
int p_size = v_per_page * (dimension + 1 + 1) + 1;
int check_size = dimension + 1;

bool delete(const char* file, int id);

/*VERY IMPORTAT!!!!!!
*This function can only use when v_MAX % v_per_page % buffer_page_max = 0 
*To make it safe.
*/
int main(){
	clock_t time = clock();
	
	bool is_find = delete("ori_bin_mnist",0);
	if(is_find){
		puts("Delete successfully!\n");
		
	}
	else 
		puts("Delete failed.\n");
	
	time = clock() - time;
	time /= CLOCKS_PER_SEC;
	printf("cmd exsting time is %ds\n", time);
}


bool delete(const char* file, int id){
	
 	// prompt to make sure the relevant info, sure--'y',and quit cmd with 'n'
	puts("Are you sure that: ");
	printf("file %s has:\n  %d vectors\n  %d dimensions\n  %d vectors per page\n",
			file ,v_MAX, dimension, v_per_page);
	printf("buffer process has:\n  %d pages in buffer\n  %d pages totally\n  %d p_size\n  %d v_size\n ",
			buffer_page_max, p_MAX, p_size, v_size);
	printf("and the id to delete is: %d\n", id);
	puts("y/n?:  ");
	if(getchar() == 'n') return false;
	


	//open the infile with a transform of path name from string to char[], and check if fopen is correct
	char fname[100];
	
	if(file[0] == 'o') {
		strcpy(fname,"D:\\DBproject\\original_data\\mnist_data\\ori_bin_mnist");
	}
	else {
		strcpy(fname,"D:\\DBproject\\pre_process_data\\mnist_data\\pre_process_mnist");
	}
	printf("fin is %s\n",fname);
	FILE* fin = fopen(fname,"r+b");
	if(ferror(fin)){
		printf("Error opening fin.\n");
		return false;
	}

	/*this is the buffer array*/
	float buffer_pages[buffer_page_max][p_size];
	
	for(int i = 0; i < buffer_page_max; i++){
		for(int j = 0; j < p_size; j++){
			buffer_pages[i][j] = 0;
		}
	}

	int mypage = (id + 1)/ v_per_page + ((id + 1) % v_per_page ? 1 : 0) ;//real page
 	int mybuffer_turn = mypage / buffer_page_max + (mypage % buffer_page_max? 1 : 0);// times to fread to get to the vector to delete 
 	int mypage_in_buffer = mypage % buffer_page_max - 1;//because the index is from 0-buffer_page_max - 1
 	int myid_in_buffer = id % v_per_page;

 	printf("page number = %d  needs buffer turn : %d  pagen_umber_in_buffer = %d  id_in_buffer = %d \n",
 			mypage, mybuffer_turn, mypage_in_buffer, myid_in_buffer);
 	puts("y/n?  :");
 	if(getchar() == 'n') return false;
 	
 	for(int i = 0; i < mybuffer_turn; i ++){
 		fread(buffer_pages,sizeof(buffer_pages),1,fin);
 	}

 	//test the id is right:
 	float myid = buffer_pages[mypage_in_buffer][myid_in_buffer * v_size];
 	printf("find id = %f\n", myid);
	
	/*
	puts("\nBefore deleting:\n");
 	for(int che = 0; che < v_per_page; che++){
 	
 		printf("check[%d] = %f    ", che,  buffer_pages[mypage_in_buffer][v_size * v_per_page + che]);

 	}
 	printf("total check = %f\n",buffer_pages[mypage_in_buffer][p_size - 1]);
 	

 	puts("Right? y/n:  ");
 	if (getchar() == 'n') return false;
	*/
 	buffer_pages[mypage_in_buffer][v_size*v_per_page + myid_in_buffer] = 0.0;
 	buffer_pages[mypage_in_buffer][p_size - 1]--;

 	/*
 	//test the delete operation in buffer is right:
 	puts("\nAfter deleting:\n");
	for(int che = 0; che < v_per_page; che++){
 	
 		printf("check[%d] = %f    ", che, buffer_pages[mypage_in_buffer][v_size * v_per_page + che]);

 	}
 	printf("total check = %f\n", buffer_pages[mypage_in_buffer][p_size - 1]);
 	*/
 	fseek(fin, -sizeof(buffer_pages), SEEK_CUR);
 	if(fwrite(buffer_pages,sizeof(buffer_pages),1, fin) != 1){
 		puts("Error write.\n");
		 return false;	
	 }

 	fseek(fin, -sizeof(buffer_pages), SEEK_CUR);
 	fread(buffer_pages,sizeof(buffer_pages),1,fin);
 	puts("\nIn the file, the check list is :\n");
	for(int che = 0; che < v_per_page; che++){
 		
 		printf("check[%d] = %f   ", che, buffer_pages[mypage_in_buffer][v_size * v_per_page + che]);

 	}
 	printf("total check = %f\n",buffer_pages[mypage_in_buffer][p_size - 1]);
 	

	fclose(fin);
	
	return true;
}


