#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>


#define ov_range 10000
#define ov_per_page 20
#define odimension 784
#define obuffer_page_max 25

#define oknn 20

int op_range = ov_range / ov_per_page + (ov_range % ov_per_page ? 1:0);
int ov_size = odimension + 1;
int op_size = ov_per_page * (odimension + 1 + 1) + 1;
int ocheck_size = odimension + 1;

struct node{
	float id;
	float distance;
};


int cmp (const void* a, const void* b);


int cmp (const void* a, const void* b){
   return (*(struct node *)a).distance > (*(struct node *)b).distance ? 1: -1;
}


bool knn_search2(int random_id ,float test2[]){
 	int process_time = op_range / obuffer_page_max + (op_range % obuffer_page_max ? 1:0);
 	struct node finall[ov_range];
	
 	float store[obuffer_page_max][op_size];
			for(int j = 0 ; j < obuffer_page_max ; j++){
				for(int k = 0 ; k < op_size ; k++){
					store[j][k] = 0 ;
				}
			}
	float myid[ov_size];
	
	for(int j = 0 ; j < ov_size ; j++){
		myid[j] = 0 ;
	}


			FILE* fin = fopen("D:\\DBproject\\pre_process_data\\mnist_data\\pre_process_mnist","rb");
			if(ferror(fin)){
					printf("Error opening fin.\n");
					return false;
			}


	


		
	//	int random_id =1;
			int page_id = random_id/ov_per_page;
			int slot_id = random_id%ov_per_page;
			int off = page_id*op_size+slot_id*ov_size;
		//	if(fseek(fin,off,0)==0) puts("haha");
			for(int j = 0 ; j < page_id ; j++){
				fread(store[0],sizeof(float)*op_size,1,fin);
			}
			for(int j = 0 ; j < slot_id ; j++){
				fread(myid,sizeof(float)*ov_size,1,fin);
			}
			fread(myid,sizeof(float)*ov_size,1,fin);
		//	printf("%d",random_id);
		//	for(int g = 0 ; g < v_size ; g++){
		//		printf("%f\n",myid[g]);
		//	}
		
		rewind(fin);
	//	puts("hah");
		int count = 0 ;
		for(int j = 0 ; j < op_range/obuffer_page_max ; j++){
			
			fread(store,sizeof(float)*op_size*obuffer_page_max,1,fin);
			for(int k = 0 ; k < obuffer_page_max ; k++){
				for(int l = 0 ; l < ov_per_page ; l++){
					if(count==ov_range){
						break;
					}
						finall[count].id= store[k][l*ov_size];
						
						float dis = 0 ;
						for(int d = 1 ; d < odimension ; d++){
						//	printf("%f",myid[d]);
							
						dis	+= (store[k][l*ov_size+d]-(float)myid[d])*(store[k][l*ov_size+d]-(float)myid[d]);
						}
					//	printf("%f",dis);
						finall[count].distance = sqrt(dis);
						count++;
					//	printf("%d\n ",count);
				}
			}

	}
	
	
			

		
		
		qsort(finall,ov_range,sizeof(finall[0]),cmp);
		for(int i = 0 ; i < 200 ; i++){
			test2[i] = finall[i].id;
		}


	
		
	

		fclose(fin);

		
		
		
 

 	

	
	
	return true;
}
