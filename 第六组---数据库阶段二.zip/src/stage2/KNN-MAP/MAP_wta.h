#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>

/*===========IMPORTANT!!============ 
* in this file the pages in buffer is doubled so remenber to:
* make buffer_page_max 1/2
*/
#define v_range 10000
#define v_per_page 2
#define dimension 7840
#define buffer_page_max 25
#define random_time 1000
#define knn 20

int p_range = v_range / v_per_page + (v_range % v_per_page ? 1:0);
int v_size = dimension + 1;
int p_size = v_per_page * (dimension + 1 + 1) + 1;
int check_size = dimension + 1;

struct Node{
	float id;
	float distance;
};

int cmp (const void* a, const void* b){
   return (*(struct Node *)a).distance > (*(struct Node *)b).distance ? 1: -1;
}

bool knn_search1(int random_id , float test2[]){
 	int process_time = p_range / buffer_page_max + (p_range % buffer_page_max ? 1:0);
 	struct Node finall[v_range];
	
 	float store[buffer_page_max][p_size];
			for(int j = 0 ; j < buffer_page_max ; j++){
				for(int k = 0 ; k < p_size ; k++){
					store[j][k] = 0 ;
				}
			}
	float myid[v_size];
	
	for(int j = 0 ; j < v_size ; j++){
		myid[j] = 0 ;
	}


			FILE* fin = fopen("D:\\DBproject\\FlyHash\\FlyWTA","rb");
			if(ferror(fin)){
					printf("Error opening fin.\n");
					return false;
			}


	
			int page_id = random_id/v_per_page;
			int slot_id = random_id%v_per_page;
			int off = page_id*p_size+slot_id*v_size;
		//	if(fseek(fin,off,0)==0) puts("haha");
			for(int j = 0 ; j < page_id ; j++){
				fread(store[0],sizeof(float)*p_size,1,fin);
			}
			for(int j = 0 ; j < slot_id ; j++){
				fread(myid,sizeof(float)*v_size,1,fin);
			}
			fread(myid,sizeof(float)*v_size,1,fin);
		//	printf("%d",random_id);
		//	for(int g = 0 ; g < v_size ; g++){
		//		printf("%f\n",myid[g]);
		//	}
		
		rewind(fin);
	//	puts("hah");
		int count = 0 ;
		for(int j = 0 ; j < p_range/buffer_page_max ; j++){
			
			fread(store,sizeof(float)*p_size*buffer_page_max,1,fin);
			for(int k = 0 ; k < buffer_page_max ; k++){
				for(int l = 0 ; l < v_per_page ; l++){
					if(count==v_range){
						break;
					}
						finall[count].id= store[k][l*v_size];
						
						float dis = 0 ;
						for(int d = 1 ; d < dimension ; d++){
						//	printf("%f",myid[d]);
							
						dis	+= (store[k][l*v_size+d]-(float)myid[d])*(store[k][l*v_size+d]-(float)myid[d]);
						}
					//	printf("%f",dis);
						finall[count].distance = sqrt(dis);
						count++;
					//	printf("%d\n ",count);
				}
			}

	}
	
	
			

		
		
		qsort(finall,v_range,sizeof(finall[0]),cmp);
		
		
			for(int i = 0 ; i < 200 ; i++){
			test2[i] = finall[i].id;
		}
		
	

		fclose(fin);

		
		
		
 

 	

	
	
	return true;
}

