#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>


#define pv_range 10000
#define pv_per_page 20
#define pdimension 784
#define pbuffer_page_max 25

#define pknn 20

int pp_range = pv_range / pv_per_page + (pv_range % pv_per_page ? 1:0);
int pv_size = pdimension + 1;
int pp_size = pv_per_page * (pdimension + 1 + 1) + 1;
int pcheck_size = pdimension + 1;

struct node{
	float id;
	float distance;
};


//int cmp (const void* a, const void* b);

int cmp (const void* a, const void* b){
   return (*(struct node *)a).distance > (*(struct node *)b).distance ? 1: -1;
}

bool knn_search2(int random_id , float test2[]){
 	int pprocess_time = pp_range / pbuffer_page_max + (pp_range % pbuffer_page_max ? 1:0);
 	struct node finall[pv_range];
	
 	float store[pbuffer_page_max][pp_size];
			for(int j = 0 ; j < pbuffer_page_max ; j++){
				for(int k = 0 ; k <pp_size ; k++){
					store[j][k] = 0 ;
				}
			}
	float myid[pv_size];
	
	for(int j = 0 ; j <pv_size ; j++){
		myid[j] = 0 ;
	}


			FILE* fin = fopen("D:\\DBproject\\pre_process_data\\mnist_data\\pre_process_mnist","rb");
			if(ferror(fin)){
					printf("Error opening fin.\n");
					return false;
			}


			
		
			int page_id = random_id/pv_per_page;
			int slot_id = random_id%pv_per_page;
			int off = page_id*pp_size+slot_id*pv_size;
		//	if(fseek(fin,off,0)==0) puts("haha");
			for(int j = 0 ; j < page_id ; j++){
				fread(store[0],sizeof(float)*pp_size,1,fin);
			}
			for(int j = 0 ; j < slot_id ; j++){
				fread(myid,sizeof(float)*pv_size,1,fin);
			}
			fread(myid,sizeof(float)*pv_size,1,fin);
		//	printf("%d",random_id);
		//	for(int g = 0 ; g < v_size ; g++){
		//		printf("%f\n",myid[g]);
		//	}
		
		rewind(fin);
	//	puts("hah");
		int count = 0 ;
		for(int j = 0 ; j < pp_range/pbuffer_page_max ; j++){
			
			fread(store,sizeof(float)*pp_size*pbuffer_page_max,1,fin);
			for(int k = 0 ; k < pbuffer_page_max ; k++){
				for(int l = 0 ; l < pv_per_page ; l++){
					if(count==pv_range){
						break;
					}
						finall[count].id= store[k][l*pv_size];
						
						float dis = 0 ;
						for(int d = 1 ; d < pdimension ; d++){
						//	printf("%f",myid[d]);
							
						dis	+= (store[k][l*pv_size+d]-(float)myid[d])*(store[k][l*pv_size+d]-(float)myid[d]);
						}
					//	printf("%f",dis);
						finall[count].distance = sqrt(dis);
						count++;
					//	printf("%d\n ",count);
				}
			}

	
	
	
			

		
		
		qsort(finall,pv_range,sizeof(finall[0]),cmp);
		for(int i = 0 ; i < 200 ; i++){
			test2[i] = finall[i].id;
		}


	
		
	}

		fclose(fin);

		
		
		
 

 	

	
	
	return true;
}
