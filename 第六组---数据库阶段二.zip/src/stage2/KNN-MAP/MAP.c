#include "MAP_ori.h"
#include "MAP_binary.h"
#define random_time 1000
float map(float test1[] , float test2[]);
int main(){
		
		
		float result;
			srand((unsigned)time( NULL ) );
		for(int i = 0 ; i < random_time ; i++){
			int random_id = rand()%v_range;
			float test[200];
			float test2[200];
			if(knn_search1(random_id,test)&&knn_search2(random_id,test2)){
				 result += map(test,test2);
				
			}
		//	printf("%d\n",i);
		}
		
		result =result/(float)random_time;
		printf("%f",result);
		system("pause");
	 	getchar();

	
		
		
		
	
}

float map(float test1[] , float test2[]){
	float sum = 0 ;
	for(int i = 0 ; i < 200 ; i++){
		for(int j = 0 ; j < 200 ; j++){
			if(test1[i-1]==test2[j-1]){
				sum += (float)(i+1)/(float)(j+1);
				break;
			}
		}
	}
	float chushu = 200;
	float num = sum /chushu;
	return num;
}
