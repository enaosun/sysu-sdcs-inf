#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>

/*===========IMPORTANT!!============ 
* in this file the pages in buffer is doubled so remenber to:
* make buffer_page_max 1/2
*/
#define v_MAX 60000
#define buffer_page_max 10
#define Fly_dimension 7840 
#define Flyish_v_per_page 2 

#define K 32



int Flyish_p_MAX = v_MAX / Flyish_v_per_page + (v_MAX % Flyish_v_per_page ? 1:0);
int Flyish_v_size = Fly_dimension + 1;
int Flyish_p_size = Flyish_v_per_page * (Fly_dimension + 1 + 1) + 1;
int Flyish_check_size = Fly_dimension + 1;


struct Node{
	float id;
	float number;
};
int cmp (const void* a, const void* b);


bool FlyWTA();

int main()
{
	//to send parameter to "mnist" or "glove"
	bool is_successful = FlyWTA();
	if(is_successful){
		puts("FlyWTA reflect seccessful!\n");

	}
	else {
		puts("FlyWTA reflect failed.\n");
	}
	return 0;
}

int cmp (const void* a, const void* b){
	 return (*(struct Node *)a).number > (*(struct Node *)b).number ? 1: -1; 
}


bool FlyWTA(){
	
	// prompt to make sure the relevant info, sure--'y',and quit cmd with 'n'
	puts("Are you sure that: ");
	printf(" buffer read has:\n  %d pages of each knid in buffer\n", buffer_page_max);
	printf("  %d pages\n  %d vectors/page\n  %d /vector size\n  %d /page size\n?y/n:  ",
		Flyish_p_MAX, Flyish_v_per_page, Flyish_v_size, Flyish_p_size);
	
	if(getchar() == 'n') return false;


	/*open the fin and fout*/
	char finname[100];
	strcpy(finname, "D:\\DBproject\\Flyish_reflect\\mnist_Flyish_Reflect");
	FILE* fin = fopen(finname, "rb");
	if(ferror(fin)){
		printf("Error opening fout.\n");
		return false;
	} 
	char foutname[100];
	strcpy(foutname, "D:\\DBproject\\FlyHash\\FlyWTA");
	FILE* fout = fopen(foutname, "wb");
	if(ferror(fout)){
		printf("Error opening fout.\n");
		return false;
	} 

	printf("fin = %s\nfout = %s\n",finname, foutname );

	float outpages[buffer_page_max][Flyish_p_size];
	float Flypages[buffer_page_max][Flyish_p_size];
	for(int i = 0; i < buffer_page_max; i ++)
	{
		for(int j = 0; j < Flyish_p_size; j++)
		{
			Flypages[i][j] = 0;
			outpages[i][j] = 0;
		}
	}

	
	struct Node store[Fly_dimension];

	int write_times = Flyish_p_MAX / buffer_page_max + (Flyish_p_MAX % buffer_page_max ? 1:0);
	int v_write_total = 0;
	int is_finish = 0;


	for(int w = 0; w < write_times; w ++)
	{
		for(int p = 0; p < buffer_page_max; p++)
		{
			fread(Flypages[p], Flyish_p_size  * 4, 1,  fin);
			if(w != 0 && Flypages[p][0] == 0.0){
				fread(Flypages[p], Flyish_p_size * 4, 1, fin);
			}
			printf("page %d's first vid = %f\n", w * buffer_page_max + p, Flypages[p][0]);
		}
		//printf("w = %d\n", w);
		for(int p = 0; p < buffer_page_max; p++)
		{


			//printf("p = %d\n", p);
			int v_in_page = 0;
			for(int v = 0; v < Flyish_v_per_page; v ++)
			{

				//set id
				int IDoffset = v*Flyish_v_size; 
				outpages[p][IDoffset] = Flypages[p][IDoffset];
				printf("\nid = %f\n", outpages[p][IDoffset]);
				//get store
				for(int d = 1; d <= Fly_dimension; d ++)
				{
					store[d-1].id = d; // d = 1-7840
					store[d-1].number = Flypages[p][IDoffset + d];
				}
				qsort(store,Fly_dimension,sizeof(store[0]),cmp);
				for(int d = 1; d <= Fly_dimension - K; d++ )
				{
					outpages[p][IDoffset + (int)store[d-1].id] = 0; // sore index is 0-7839
					//printf("  %f  ", outpages[p][IDoffset + (int)store[d-1].id] );
				}
				for(int d = Fly_dimension - K + 1; d <= Fly_dimension; d ++)
				{
					outpages[p][IDoffset + (int)store[d-1].id] = Flypages[p][IDoffset + (int)store[d-1].id];
					//printf("  %f  ", outpages[p][IDoffset + (int)store[d-1].id] );
				}

				v_write_total++;
				v_in_page ++;
				if(v_write_total == v_MAX)
				{
					is_finish = 1;
					break;
				}
			}

			for(int check = 0; check < v_in_page; check ++)
			{
				outpages[p][Flyish_v_size * Flyish_v_per_page + check]= 1.0;

			}
			for(int check = v_in_page; check <= Flyish_v_per_page - v_in_page; check ++ )
			{
				outpages[p][Flyish_v_per_page * Flyish_v_size + check] = 0;
			}

			if(is_finish) break;
		}
		if(1!=fwrite(outpages, sizeof(outpages), 1, fout))
		{
			puts("Fwrite error.\n");
			return false;
		}
		
		if(is_finish) break;

	}



	fclose(fin);
	fclose(fout);

	return true;
}
