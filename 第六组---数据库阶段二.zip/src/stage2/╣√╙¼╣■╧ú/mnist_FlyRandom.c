#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>

/*===========IMPORTANT!!============ 
* in this file the pages in buffer is doubled so remenber to:
* make buffer_page_max 1/2
*/
#define v_MAX 60000
#define buffer_page_max 10
#define Fly_dimension 7840 
#define Flyish_v_per_page 2 

#define K 32
#define FlyRandom_v_per_page 481


int Flyish_p_MAX = v_MAX / Flyish_v_per_page + (v_MAX % Flyish_v_per_page ? 1:0);
int Flyish_v_size = Fly_dimension + 1;
int Flyish_p_size = Flyish_v_per_page * (Fly_dimension + 1 + 1) + 1;
int Flyish_check_size = Fly_dimension + 1;

int FlyRandom_p_MAX = v_MAX / FlyRandom_v_per_page + (v_MAX % FlyRandom_v_per_page ? 1:0);
int FlyRandom_v_size = K + 1;
int FlyRandom_p_size = FlyRandom_v_per_page * (K + 1 + 1) + 1;
int FlyRandom_check_size = K + 1;

bool FlyRandom();

int main()
{
	//to send parameter to "mnist" or "glove"
	bool is_successful = FlyRandom();
	if(is_successful){
		puts("FlyRandom reflect seccessful!\n");

	}
	else {
		puts("FlyRandom reflect failed.\n");
	}
	return 0;
}


bool FlyRandom(){
	
	// prompt to make sure the relevant info, sure--'y',and quit cmd with 'n'
	puts("Are you sure that: ");
	printf(" buffer read has:\n  %d pages of each knid in buffer\n", buffer_page_max);
	printf("  %d pages\n  %d vectors/page\n  %d /vector size\n  %d /page size\n?y/n:  ",
		FlyRandom_p_MAX, FlyRandom_v_per_page, FlyRandom_v_size, FlyRandom_p_size);
	
	if(getchar() == 'n') return false;

	//form random array:
	int random_cols[K];
	for(int i = 0; i < K; i ++)
	{
		random_cols[i] = 0;
	}

	printf("Forming random_cols[]:\n");
	srand((int)time(0));
	for(int i = 0; i < K; i ++)
	{
		random_cols[i] = rand()%(Fly_dimension - 1) + 1;
		printf("  %d  ", random_cols[i] );
	}
	

	/*open the fin and fout*/
	char finname[100];
	strcpy(finname, "D:\\DBproject\\Flyish_reflect\\mnist_Flyish_Reflect");
	FILE* fin = fopen(finname, "rb");
	if(ferror(fin)){
		printf("Error opening fout.\n");
		return false;
	} 
	char foutname[100];
	strcpy(foutname, "D:\\DBproject\\FlyHash\\FlyRandom");
	FILE* fout = fopen(foutname, "wb");
	if(ferror(fout)){
		printf("Error opening fout.\n");
		return false;
	} 

	printf("fin = %s\nfout = %s\n",finname, foutname );

	
	float Flypages[buffer_page_max][Flyish_p_size];
	for(int i = 0; i < buffer_page_max; i ++)
	{
		for(int j = 0; j < Flyish_p_size; j++)
		{
			Flypages[i][j] = 0;
		}
	}

	float outpages[buffer_page_max][FlyRandom_p_size];
	for(int i = 0; i < buffer_page_max; i ++)
	{
		for(int j = 0; j < FlyRandom_p_size; j++)
		{
			outpages[i][j] = 0;
		}
	} 
	
	for(int p = 0; p < buffer_page_max; p++)
	{
		fread(Flypages[p], sizeof(Flypages[p]), 1, fin);
		//printf("first id of page %d is %f \n",p, Flypages[p][0]);
	}
	
	int write_times = FlyRandom_p_MAX / buffer_page_max + (FlyRandom_p_MAX % buffer_page_max ? 1:0);

	int v_write_total = 0;
	int f_pid = 0, f_vid = 0;
	int is_finish = 0;
	for(int w = 0; w < write_times; w ++)
	{

		//printf("w = %d\n", w);
		for(int p = 0; p < buffer_page_max; p++)
		{
			//printf("p = %d\n", p);
			int v_in_page = 0;
			for(int v = 0; v < FlyRandom_v_per_page; v ++)
			{
				
				outpages[p][v*FlyRandom_v_size] = Flypages[f_pid][Flyish_v_size * f_vid];
				printf("vector %f\n", outpages[p][v*FlyRandom_v_size]);
				for(int d = 0; d < K; d ++)
				{
					int offset = f_vid * Flyish_v_size + random_cols[d];
					outpages[p][v * FlyRandom_v_size + d + 1] = Flypages[f_pid][offset];
					//printf("  %f  ",Flypages[f_pid][offset] );
				}

				v_write_total ++;
				printf("  %d   ", v_write_total);
				v_in_page ++;
				if(v_write_total == v_MAX)
				{
					is_finish = 1;
					break;
				}

				f_vid ++;
			
				if(f_vid == Flyish_v_per_page)
				{
					f_pid ++;
					f_vid = 0;
					if(f_pid == buffer_page_max)
					{
						
						f_pid = 0;
						for(int fp = 0; fp < buffer_page_max; fp ++)
						{
							//printf("\n\nfp = %d\n", fp);
							fread(Flypages[fp], sizeof(Flypages[fp]), 1, fin);
							if(Flypages[fp][0] == 0.0)
							{
								fread(Flypages[fp], sizeof(Flypages[fp]), 1, fin);
							}

							//printf(" pid = %f\n", Flypages[fp][0]);
						}
					}

				}
			}

			for(int check = 0; check < v_in_page; check ++)
			{
				outpages[p][FlyRandom_v_size * FlyRandom_v_per_page + check]= 1.0;

			}
			for(int check = v_in_page; check <= FlyRandom_v_per_page - v_in_page; check ++ )
			{
				outpages[p][FlyRandom_v_per_page * FlyRandom_v_size + check] = 0;
			}

			if(is_finish) break;
		}
		if(1!=fwrite(outpages, sizeof(outpages), 1, fout))
		{
			puts("Fwrite error.\n");
			return false;
		}
		
		if(is_finish) break;

	}



	fclose(fin);
	fclose(fout);

	return true;
}
