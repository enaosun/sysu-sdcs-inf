#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>

/*===========IMPORTANT!!============ 
* in this file the pages in buffer is doubled so remenber to:
* make buffer_page_max 1/2
*/
#define v_MAX 60000//  glove : 2196017, mnist: 60000
#define v_per_page 20 //  glove : 54, mnist: 20
#define dimension 784 //  glove : 300, mnist: 784
#define buffer_page_max 15 // 2*buffer_page_max > 30 may BAO NEI CUN !!!
#define Fly_dimension 7840 // 10*dimension
#define Fly_index_quantity  78 // glove: 30, mnist: 78
#define Flyish_v_per_page 2 // glove: 5, mnist : 2
#define matix_row_length 98

int p_MAX = v_MAX / v_per_page + (v_MAX % v_per_page ? 1:0);
int v_size = dimension + 1;
int p_size = v_per_page * (dimension + 1 + 1) + 1;
int check_size = dimension + 1;


int Flyish_p_MAX = v_MAX / Flyish_v_per_page + (v_MAX % Flyish_v_per_page ? 1:0);
int Flyish_v_size = Fly_dimension + 1;
int Flyish_p_size = Flyish_v_per_page * (Fly_dimension + 1 + 1) + 1;
int Flyish_check_size = Fly_dimension + 1;


bool mnist_Flyish();

int main()
{
	//to send parameter to "mnist" or "glove"
	bool is_successful = mnist_Flyish();
	if(is_successful){
		puts("Flyish reflect seccessful!\n");

	}
	else {
		puts("Flyish reflect failed.\n");
	}
	return 0;
}

bool mnist_Flyish(){


	/*open the fmatrix , fin and fout*/
	char matrixname[100];
	char finname[100];
	char foutname[100];
	
	strcpy(finname, "D:\\DBproject\\pre_process_data\\mnist_data\\pre_process_mnist");
	strcpy(foutname, "D:\\DBproject\\Flyish_reflect\\mnist_Flyish_Reflect_try");
	strcpy(matrixname, "D:\\DBproject\\Flyish_reflect\\lazy_mnist_Flyish_Matrix");

	// prompt to make sure the relevant info, sure--'y',and quit cmd with 'n'	puts("Are you sure that: ");
	printf(" file %s has:\n  %d vectors\n  %d dimensions\n  %d vectors per page\n",
			finname ,v_MAX, dimension, v_per_page);
	//printf(" fread times is %d\n", read_times);
	printf(" buffer read has:\n  %d pages of each knid in buffer\n", buffer_page_max);
	printf(" for reflection of %s\n",finname);
	printf("  %d pages\n  %d vectors/page\n  %d /vector size\n  %d /page size\n?y/n:  ",Flyish_p_MAX, Flyish_v_per_page, Flyish_v_size, Flyish_p_size);
	
	if(getchar() == 'n') return false;

	FILE* fmatrix = fopen(matrixname, "rb");
	if(ferror(fmatrix)){
		printf("Error opening fmatrix.\n");
		return false;
	} 
	FILE* fin = fopen(finname, "rb");
	if(ferror(fin)){
	
		printf("Error opening fin.\n");
		return false;
	} 
	FILE* fout = fopen(foutname, "wb");
	if(ferror(fout)){
		printf("Error opening fout.\n");
		return false;
	} 

	//read matrix
	int Flyish_Matrix[matix_row_length][Fly_index_quantity];
	for(int i = 0; i < matix_row_length; i ++){
		for (int j = 0; j < Fly_index_quantity ; j++)
		{	
			Flyish_Matrix[i][j]=0;

		}
	}
	fread(Flyish_Matrix, sizeof(Flyish_Matrix), 1,fmatrix);
	fclose(fmatrix);
	
	/*test matrix read
	for(int i = 0; i < matix_row; i ++){
		printf("\n");
		for (int j = 0; j < Fly_index_quantity ; j++)
		{	
			printf("%d  ",Flyish_Matrix[i][j] );

		}
		printf("\n");
	}
	*/
	//init
	float buffer_pages[buffer_page_max][p_size];
	float reflect_pages[buffer_page_max][Flyish_p_size];

	for(int i = 0; i < buffer_page_max; i++)
	{
		for(int j = 0; j < p_size; j++)
		{
			buffer_pages[i][j] = 0.0;
		}
	}

	for(int i = 0; i < buffer_page_max; i++)
	{
		for(int j = 0; j < Flyish_p_size; j++)
		{
			reflect_pages[i][j] = 0.0;
		}
	}


puts("haha\n");

	int read_times = p_MAX / buffer_page_max + (p_MAX % buffer_page_max ? 1:0);//times to read the pre_process_data
	int v_read_total = 0; // total numbers of vectors that have read into buffer
	int p_read_total = 0; //total numbers of pages that have read into buffer
	int p_reflect_total = 0;// total numbers of pages that have write to the reflection file
	int write_pid = 0; // index for page id in the buffer
	int write_vid = 0; //index for vector id in the buffer 

	int is_finish = 0;
	for(int r = 0; r < read_times ; r++)
	{

		//printf("the %d read of pre_process\n", r );
		
		//loop read and revise the pre_process data into the buffer pages------avoid the strange jump of fin
		for(int k = 0; k < buffer_page_max ; k ++)
		{
			//fread(buffer_pages, sizeof(buffer_pages), 1, fin);
			fread(buffer_pages[k], sizeof(buffer_pages[k]), 1,  fin);
			if(r !=0 && buffer_pages[k][0] == 0.0)
			{
				fread(buffer_pages[k], sizeof(buffer_pages[k]), 1, fin);
			}
			//printf("page %d's first vid = %f\n", r * buffer_page_max + k, buffer_pages[k][0]);
		}

		for(int p = 0 ; p < buffer_page_max; p++)
		{
			int matrix_row = 0; // the row number of matrix 

			for(int v = 0; v < v_per_page; v++)
			{

				//if page full, set check , pid++ ,page total++, if need to write, //normal case
				if(v_read_total != v_MAX && write_vid == Flyish_v_per_page)
				{	
					//printf("write vid  = %d\n", write_vid);
					//set check
					for(int check = 0; check < write_vid; check ++)
					{
						reflect_pages[write_pid][Flyish_v_size*Flyish_v_per_page + check] = 1.0;
					}

					reflect_pages[write_pid][Flyish_p_size - 1] = write_vid;//actually record the quantity of vectors/page
						
					write_vid = 0;
					write_pid ++;
					p_reflect_total++;

					//printf("write_pid === %d\n", write_pid);
					if (write_pid == buffer_page_max )
					{
						//printf("have reflect total pages = %d\n", p_reflect_total);
							
						write_pid = 0;
						//and don't need to cover reflect_pages[][] with “0”
						if(fwrite(reflect_pages, sizeof(reflect_pages), 1, fout) != 1){
							puts("Fwrite error.\n");
							
							return false;
						}


						//and if it is the second time to read the matrix, that is ,when the rmt == 1 
					}	
				}
				else if (v_read_total == v_MAX)
				{
					for(int check = 0; check < write_vid; check ++)
					{
						reflect_pages[write_pid][Flyish_v_size*Flyish_v_per_page + check] = 1.0;
					}

					reflect_pages[write_pid][Flyish_p_size - 1] = write_vid;//actually record the quantity of vectors/page
							
					write_vid = 0;
					write_pid ++;
					p_reflect_total++;

					//printf("write_pid === %d\n", write_pid);

					if(fwrite(reflect_pages, sizeof(reflect_pages), 1, fout) != 1)
					{
						puts("Fwrite error.\n");
							
						return false;
					}

					is_finish = 1;
					break;
				}

				//set vector id
				//printf("v_read_total = %d\n", v_read_total);
				//if(buffer_pages[p][v*v_size] != reflect_pages[write_pid][write_vid*Flyish_v_size])
				//{
					//printf("\nid =  %f  to  \n", reflect_pages[write_pid][write_vid * Flyish_v_size]);

					reflect_pages[write_pid][write_vid * Flyish_v_size] = buffer_pages[p][v*v_size]; //set id
				//}
					//printf("reflect id =  %f\n", reflect_pages[write_pid][write_vid * Flyish_v_size]);
							
				//write one reflection vector

				for(int rd = 1; rd <= Fly_dimension; rd++)
				{
					for(int m_col = 0; m_col < Fly_index_quantity; m_col ++)
					{
						int offset = v*v_size+ Flyish_Matrix[matrix_row][m_col];
					//	if(buffer_pages[p][offset] != 0)
					//		printf("index %d = %f\n", Flyish_Matrix[matrix_row][m_col], buffer_pages[p][offset]);
						reflect_pages[write_pid][write_vid*Flyish_v_size+rd] += buffer_pages[p][v*v_size+ Flyish_Matrix[matrix_row][m_col]];
					}
					//if(reflect_pages[write_pid][write_vid*Flyish_v_size+rd] != 0)
						//printf("reflect[%d][%d] = %f     \n\n",write_pid, write_vid*Flyish_v_size+rd,reflect_pages[write_pid][write_vid*Flyish_v_size+rd] );
					matrix_row ++;
					matrix_row %= matix_row_length;
				}
						
				write_vid ++;
				v_read_total++;
				
				//printf("readtotal === %d\n", v_read_total);
							 	

			}

			p_read_total++;
			if(is_finish) break;
				
		}

		if(is_finish) break;
	}
	fclose(fin);
	fclose(fout);
	return true;
}
