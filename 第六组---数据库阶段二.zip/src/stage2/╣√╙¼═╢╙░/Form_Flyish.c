#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>


#define Mdimension 784
#define Gdimension 300
#define Fly_Mdimension 98
#define Fly_Gdimension 3000
#define p 0.1
bool Flyish_Matrix();

int main()
{
	int is_successful = Flyish_Matrix("mnist");
	if(!is_successful){
		printf("\n\nError forming.\n");
	}
	else
		printf("\n\nForming successfully!\n");

	return 0;
}

bool Flyish_Matrix(const char* file){
	


	int i = 0, j = 0,dimension = 0;


	char fname[100];
	char fname_another[100];
	if(file[0] == 'm'){
		strcpy(fname, "D:\\DBproject\\Flyish_reflect\\lazy_mnist_Flyish_Matrix");
		
	 	i = Fly_Mdimension, j = p*Mdimension, dimension = Mdimension;
	 	printf("Are you sure that to form Flyish matrix for %s :\n",file );
		printf("There are:\n %d rows\n %d cols\n p = %f\ny/n?:  ", i, j, p);

		if(getchar() == 'n') return false;
		
		FILE* fout = fopen(fname, "wb");
		if(ferror(fout)){
			printf("Error opening fout.\n");
			return false;
		} 

		int Flyish_Matrix[i][j];
		for(int row = 0; row < i/2; row ++){
			for(int col =0; col < j ; col++){
				Flyish_Matrix[row][col] = 0;
			}
		}
		//puts("haha2\n");
		srand((int)time(0));
		for(int row = 0; row < i; row ++){
			puts("\n");
			printf("\n row = %d\n", row);
			for(int col =0; col < j ; col++){
				Flyish_Matrix[row][col] = rand()%(dimension - 1) + 1; //1-784
				printf(" %d    ",Flyish_Matrix[row][col]);//matrix[%d][%d] = ,    row,col, 
			}
		}

		if(fwrite(Flyish_Matrix, sizeof(Flyish_Matrix), 1, fout) != 1){
			printf("Error write.\n");
			fclose(fout);
			return false;
		}
		fclose(fout);
		/*
		strcpy(fname, "D:\\DBproject\\Flyish_reflect\\mnist_Flyish_Matrix2" );
		fout = fopen(fname, "wb");
		if(ferror(fout)){
			printf("Error opening fout.\n");
			return false;
		} 
		
		for(int row = 0; row < i/2; row ++){
			printf("\n row = %d\n", row);
			for(int col =0; col < j ; col++){
				Flyish_Matrix[row][col] = rand()%(dimension - 1) + 1;
				printf("matrix[%d][%d] = %d    ",row,col, Flyish_Matrix[row][col]);
			}
		}

		if(fwrite(Flyish_Matrix, sizeof(Flyish_Matrix), 1, fout) != 1){
			printf("Error write.\n");
			fclose(fout);
			return false;
		}
		
		fclose(fout);
		*/


	}
	else{
		strcpy(fname, "D:\\DBproject\\Flyish_reflect\\glove_Flyish_Matrix");
		i = Fly_Gdimension, j= p*Gdimension, dimension = Gdimension;

		printf("Are you sure that to form Flyish matrix for %s :\n",file );
		printf("There are:\n %d rows\n %d cols\n p = %f\ny/n?:  ", i, j, p);

		if(getchar() == 'n') return false;
		
		FILE* fout = fopen(fname, "wb");
		if(ferror(fout)){
			printf("Error opening fout.\n");
			return false;
		} 

		int Flyish_Matrix[i][j];
		for(int row = 0; row < i/2; row ++){
			for(int col =0; col < j ; col++){
				Flyish_Matrix[row][col] = 0;
			}
		}
		//puts("haha2\n");
		srand((int)time(0));
		for(int row = 0; row < i; row ++){
			printf("\n row = %d\n", row);
			for(int col =0; col < j ; col++){
				Flyish_Matrix[row][col] = rand()%(dimension - 1) + 1;
				//printf("matrix[%d][%d] = %d    ",row,col, Flyish_Matrix[row][col]);
			}
		}

		if(fwrite(Flyish_Matrix, sizeof(Flyish_Matrix), 1, fout) != 1){
			printf("Error write.\n");
			fclose(fout);
			return false;
		}
		fclose(fout);
	}


	
	

	/*very IMPORTANT!!!!!
	*my buffer explose when the row is i
	*I think it is because the buffer pages are more than 30
	*SO I set the row to i/2 to avoid buffer out of size
	*/
	 
	
	return true;
   
}	

