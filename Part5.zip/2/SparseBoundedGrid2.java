import info.gridworld.grid.Grid;
import info.gridworld.grid.AbstractGrid;
import info.gridworld.grid.Location;

import java.util.*;
/**
 * A <code> SparseBoundedGrid</code> is a rectangular grid with a finite number of
 * rows and columns. <br />
 * The implementation of this class is testable on the AP CS AB exam.
 *
 *
 */
public class SparseBoundedGrid2<E> extends AbstractGrid<E>{
	private int col;
	private int row;
	private Map<Location,E> occupants;
/**
     * Constructs an empty bounded grid with the given dimensions.
     * (Precondition: <code>rows > 0</code> and <code>cols > 0</code>.)
     * @param rows number of rows in BoundedGrid
     * @param cols number of columns in BoundedGrid
     */
	public SparseBoundedGrid2(int c,int r){
		if (r <= 0)
            throw new IllegalArgumentException("rows <= 0");
        if (c <= 0)
            throw new IllegalArgumentException("cols <= 0");
        row = r;
        col = c;
        occupants = new HashMap<Location,E>();

	}

	public int getNumRows()
    {
        return row;
    }

 	public int getNumCols()
    {
        // Note: according to the constructor precondition, numRows() > 0, so
        // theGrid[0] is non-null.
        return col;
    }

	public boolean isValid(Location loc){
		 return 0 <= loc.getRow() && loc.getRow() < getNumRows()
                && 0 <= loc.getCol() && loc.getCol() < getNumCols();
	}

	public ArrayList<Location> getOccupiedLocations(){
		 ArrayList<Location> theLocations = new ArrayList<Location>();
     for (Location l : occupants.keySet()) {
       theLocations.add(l);
     }
		 return theLocations;
	}

	public E get(Location loc)
    {
        if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
      
      return (E)occupants.get(loc);
    }

    public E remove(Location loc){
    	 if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
       	E temp = get(loc);
       	if(temp == null) {
            return null;}
       	else {
          occupants.remove(loc);
        }
       	return temp;
    }

    public E put(Location loc, E obj)
    {
        if (!isValid(loc))
            {throw new IllegalArgumentException("Location " + loc
                    + " is not valid");}
        if (obj == null)
            throw new NullPointerException("obj == null");

        // Add the object to the grid.
        E old = remove(loc);
        occupants.put(loc,obj);
        return old;
    }

}