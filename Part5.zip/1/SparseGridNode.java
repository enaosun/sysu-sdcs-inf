public class SparseGridNode{
	private Object occupant;
	private int col;
	private SparseGridNode next;

	public SparseGridNode(Object o,int c ,SparseGridNode s){
		occupant = o;
		col = c;
		next = s;
	}

	public Object getOccupant(){
		return  occupant;
	}

	public SparseGridNode getNext(){
		return next;
	}

	public int getCol(){
		return col;
	}

	public void setNext(SparseGridNode n){
		next = n;
	}
	public void setOccupant(Object o){
		occupant = o;
	}
}
