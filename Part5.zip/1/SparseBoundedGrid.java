import info.gridworld.grid.Grid;
import info.gridworld.grid.AbstractGrid;
import info.gridworld.grid.Location;

import java.util.ArrayList;
/*
this use SparseGridNode to 
create SparseBoundedGrid
*
*/

/**
 * A <code> SparseBoundedGrid</code> is a rectangular grid with a finite number of
 * rows and columns. <br />
 * The implementation of this class is testable on the AP CS AB exam.
 */
public class SparseBoundedGrid<E> extends AbstractGrid<E>{
	private int col;
	private int row;
	private SparseGridNode[] occupants;
   /**
     * Constructs an empty bounded grid with the given dimensions.
     * (Precondition: <code>rows > 0</code> and <code>cols > 0</code>.)
     * @param rows number of rows in BoundedGrid
     * @param cols number of columns in BoundedGrid
     */
	public SparseBoundedGrid(int c,int r){
		if (r <= 0)
            throw new IllegalArgumentException("rows <= 0");
        if (c <= 0)
            throw new IllegalArgumentException("cols <= 0");
        row = r;
        col = c;
        occupants = new SparseGridNode[r];
	}

	public int getNumRows()
    {
        return row;
    }

 	public int getNumCols()
    {
        // Note: according to the constructor precondition, numRows() > 0, so
        // theGrid[0] is non-null.
        return col;
    }

	public boolean isValid(Location loc){
		 return 0 <= loc.getRow() && loc.getRow() < getNumRows()
                && 0 <= loc.getCol() && loc.getCol() < getNumCols();
	}
     /*
to getOccupiedLocations
*
     */

	public ArrayList<Location> getOccupiedLocations(){
		 ArrayList<Location> theLocations = new ArrayList<Location>();
		 for (int i = 0;i < row ;i++) {
		 	SparseGridNode head = occupants[i];
		 	while (head != null) {
		 		int c = head.getCol();
		 		Location loc = new Location(i , c);
		 		theLocations.add(loc);
		 		head = head.getNext();
		 	}
		 }
		 return theLocations;
	}

	public E get(Location loc)
    {
        if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
       SparseGridNode head = occupants[loc.getRow()];
       while (head!=null) {
       	if(head.getCol() == loc.getCol()){
       		return (E) head.getOccupant();
       	}
       	head = head.getNext();
       }
       E t = null;
       return t;
    }

    public E remove(Location loc){
    	 if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
       	E temp = get(loc);
       	if(temp == null) return null;
       	else {
       		SparseGridNode first = occupants[loc.getRow()];
       		if(first.getCol()==loc.getCol()){
       			occupants[loc.getRow()] = null;
       			return temp;
       		}
       		SparseGridNode next = first.getNext();
       		while(next!=null){
       			if(next.getCol() == loc.getCol()){
       				first.setNext(next.getNext());
       				break;
       			}else {
       				next=next.getNext();
       				first=first.getNext();
       			}
       		}
       	}
       	return temp;
    }

    public E put(Location loc, E obj)
    {
        if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
        if (obj == null)
            throw new NullPointerException("obj == null");

        // Add the object to the grid.
        E old = remove(loc);
        SparseGridNode head = occupants[loc.getRow()];
        occupants[loc.getRow()]=new SparseGridNode(obj, loc.getCol(),head);
        return old;
    }

}