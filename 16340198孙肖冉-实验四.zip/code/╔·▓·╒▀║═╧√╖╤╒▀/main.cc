#include <bits/stdc++.h>
#include <semaphore.h>
#include <sys/types.h>
#include <pthread.h>
#include <cstdlib>
#include <unistd.h>
#include <cstring>
#include <iostream>
using  namespace std;

/* define a struct to 
	send check information
	and some variables*/
#define BUFFER_SIZE 4 
int NumberOfProducer = 0 ;
int NumberOfCustomer = 0;
int buffer[BUFFER_SIZE];
int NextOfProducer = 0;
int NextOfCustomer = 0;

sem_t sign,empty,full;


struct Check{
	int pid;
	char role;
	int StartTime;
	int LastTime;
	int num;
};

void *Customer(void* test){
	struct Check* data = (struct Check*)test;
	

	while(1){
		sem_wait(&full);
		sleep(data->StartTime);
		sem_wait(&sign);




		cout << "Customer NO." << data->pid << " Uses Product NO. "
			 << buffer[NextOfCustomer]<<endl;
		buffer[NextOfCustomer] = 0;
		NextOfCustomer = (NextOfCustomer+1)%BUFFER_SIZE;


		sleep(data->LastTime);
		sem_post(&sign);
		sem_post(&empty);

		pthread_exit(0);


	}
}

void *Producer(void* test){
	struct Check* data = (struct Check*)test;

	while(1){
		sem_wait(&empty);
		sleep(data->StartTime);
		sem_wait(&sign);

		buffer[NextOfProducer] = data->num;
		cout << "Producer NO." << data->pid << " Produces Product " << "NO."
				<< data->num << endl;;

		NextOfProducer = (NextOfProducer+1)%BUFFER_SIZE;

		sleep(data->LastTime);
		sem_post(&sign);
		sem_post(&full);

		pthread_exit(0);

	}
}



int main(int argc,char**argv){
	int sum = atoi(argv[1]);
	if(sum > 6||sum < 0){
		cout << "please enter the number between 0 to 6" << endl;
		exit(0);
	}
	struct Check test[sum];
	pthread_t Pid[sum];

	sem_init(&empty,0,BUFFER_SIZE);
	sem_init(&full,0,0);
	sem_init(&sign,0,1);

	for(int i = 0 ; i < BUFFER_SIZE ;i++){
		buffer[i] = 0 ;
	}

	ifstream input("data.txt");

	if(!input.is_open()){
		exit(1);
	}

	char store[300];
	int index = 0;
	char temp;
	while(!input.eof()){
		input.read(&temp,1);
		if(temp!=' '&&temp!='\n'&&temp!='\r'){
			store[index]=temp;
			index++;
			
		}
	}
	index = 0 ;
	for(int i = 0 ; i < sum ; i++){
		
		test[i].pid = store[index] -'0';
		index++;
		//cout << test[i].pid << endl;
		test[i].role = store[index];
		index++;
		//cout << test[i].role << endl;
		test[i].StartTime = store[index]-'0';
		index++;
		//cout << test[i].StartTime;
		test[i].LastTime = store[index]-'0';
		index++;
		if(test[i].role == 'P'){
			test[i].num = store[index]-'0';
			index++;
		}
	}
	cout << "===================================" << endl;
	for(int i = 0 ; i < sum ; i++){
		if(test[i].role=='P'){
			NumberOfProducer++;
			pthread_create(&Pid[i],NULL,Producer,&test[i]);
			cout << "Construct A Producer Thread NO." << test[i].pid
				<<endl; 
		}
		if(test[i].role == 'C'){
			NumberOfCustomer++;
			pthread_create(&Pid[i],NULL,Customer,&test[i]);
			cout << "Construct A Customer Thread NO." << test[i].pid
				<<endl;
		}

	}
	cout << "===================================" << endl;
	for(int i = 0 ; i < sum ; i++){
		pthread_join(Pid[i],NULL);
	}

	sem_destroy(&full);
	sem_destroy(&empty);
	sem_destroy(&sign);

}