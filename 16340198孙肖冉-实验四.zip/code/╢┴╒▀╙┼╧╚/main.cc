#include <bits/stdc++.h>
#include <semaphore.h>
#include <sys/types.h>
#include <pthread.h>
#include <cstdlib>
#include <unistd.h>
#include <cstring>
#include <iostream>
using  namespace std;


int NumOfReader = 0 ;
int number_count = 0 ;
sem_t read_write;
sem_t change;

struct Check{
	int pid;
	char role;
	int StartTime;
	int LastTime;
};

void *Writer(void *test){
	struct Check* data = (struct Check*)test;
	while(1){

		sleep(data->StartTime);
		sem_wait(&read_write);
		cout << "THE WRITER NO." << data->pid 
				<< " SUBMIT REQUEST" << endl;

		cout << "THE WRITER NO." << data->pid
			<<" WRITE THE NUMBER " << number_count << endl;
		number_count++;

		sleep(data->LastTime);
		cout  << "THE WRITER NO." << data->pid 
				<< " STOPS THE PTHREAD" << endl;

		sem_post(&read_write);
		pthread_exit(0);
		
	}

}

void* Reader(void *test){
	struct Check* data = (struct Check*)test;
	while(1){
		//cout << "--------------------------------"<<endl;
		sleep(data->StartTime);
		sem_wait(&change);
		cout << "THE READER NO." << data->pid 
				<< " SUBMIT REQUEST" << endl;

		NumOfReader++;
		if(NumOfReader==1){
			sem_wait(&read_write);
		}
		sem_post(&change);

		cout << "THE READER NO." << data->pid 
			<< " READ THE NUMBER " << number_count << endl;
	//	count++;

		sleep(data->LastTime);
		cout  << "THE READER NO." << data->pid 
				<< " STOPS THE PTHREAD" << endl;

		sem_wait(&change);
		NumOfReader--;
		if(NumOfReader==0){
			sem_post(&read_write);
		}
		sem_post(&change);
		pthread_exit(0);
		
	}
}

int main(int argc , char** argv){
	int sum = atoi(argv[1]);
	struct Check test[sum];
	pthread_t pid[sum];
	sem_init(&read_write,0,1);
	sem_init(&change,0,1);

	ifstream input("data.txt");

	if(!input.is_open()){
		exit(1);
	}

	char store[300];
	int index = 0;
	char temp;
	while(!input.eof()){
		input.read(&temp,1);
		if(temp!=' '&&temp!='\n'&&temp!='\r'){
			store[index]=temp;
			index++;
		//cout << temp << endl;	
		}
	}
	index = 0 ;
	for(int i = 0 ; i < sum ; i++){
		
		test[i].pid = store[index] -'0';
		index++;
		//cout << "========";
		//cout << test[i].pid << endl;
		test[i].role = store[index];
		index++;
		//cout << test[i].role << endl;
		test[i].StartTime = store[index]-'0';
		index++;
		//cout << test[i].StartTime;
		test[i].LastTime = store[index]-'0';
		index++;
	}
	cout << "=================================="<<endl;
	for(int i = 0 ; i < sum ; i++){

		if(test[i].role == 'R'){
			pthread_create(&pid[i],NULL,Reader,&test[i]);
			cout << "CONSTRUCT A  READER PTHREAD NO."
			<<test[i].pid  << endl;
		}
		if(test[i].role == 'W'){
			pthread_create(&pid[i],NULL,Writer,&test[i]);
			cout << "CONSTRUCT A  WRITER PTHREAD NO."
			<<test[i].pid  << endl;
		}
	}
	cout << "=================================="<<endl;
	for(int i = 0 ; i < sum ; i++){
		pthread_join(pid[i],NULL);
	}

	sem_destroy(&read_write);
	sem_destroy(&change);


}

