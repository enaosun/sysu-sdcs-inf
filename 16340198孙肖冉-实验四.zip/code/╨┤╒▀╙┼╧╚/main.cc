#include <bits/stdc++.h>
#include <semaphore.h>
#include <sys/types.h>
#include <pthread.h>
#include <cstdlib>
#include <unistd.h>
#include <cstring>
#include <iostream>
using  namespace std;


int NumOfReader = 0 ;
int NumOfWriter = 0 ;
int number_count = 0 ;
sem_t writeaccess;
sem_t readaccess;
sem_t Reader_Change;
sem_t Writer_Change;

struct Check{
	int pid;
	char role;
	int StartTime;
	int LastTime;
};

void *Writer(void *test){
	struct Check* data = (struct Check*)test;
	while(1){
		sleep(data->StartTime);
		sem_wait(&writeaccess);
		cout << "THE WRITER NO." << data->pid 
				<< " SUBMIT REQUEST" << endl;

		NumOfWriter++;
		if(NumOfWriter==1){
			sem_wait(&Reader_Change);
		}
		sem_post(&writeaccess);

		sem_wait(&Writer_Change);
		cout << "THE WRITER NO." << data->pid
			 << " WRITE THE NUMBER " << number_count << endl;
		number_count++;

		sleep(data->LastTime);
		cout  << "THE WRITER NO." << data->pid 
				<< " STOPS THE PTHREAD" << endl;

		sem_post(&Writer_Change);
		NumOfWriter--;
		if(NumOfWriter==0){
			sem_post(&Reader_Change);
		}
		sem_post(&writeaccess);
		pthread_exit(0);

	}

}

void* Reader(void *test){
	struct Check* data = (struct Check*)test;
	while(1){
		sleep(data->StartTime);
		sem_wait(&Reader_Change);
		sem_wait(&readaccess);
		cout << "THE READER NO." << data->pid 
				<< " SUBMIT REQUEST" << endl;

		NumOfReader++;
		if(NumOfReader==1){
			sem_wait(&Writer_Change);
		}
		sem_post(&readaccess);
		sem_post(&Reader_Change);

		cout << "THE READER NO." << data->pid 
		<< " READ THE NUMBER " << number_count << endl;
	//	count++;

		sleep(data->LastTime);
		cout  << "THE READER NO." << data->pid 
				<< " STOPS THE PTHREAD" << endl;

		sem_wait(&readaccess);
		NumOfReader--;
		if(NumOfReader==0){
			sem_post(&Writer_Change);
		}
		sem_post(&readaccess);
		pthread_exit(0);

	}
}

int main(int argc , char** argv){
	int sum = atoi(argv[1]);
	struct Check test[sum];
	pthread_t pid[sum];

	sem_init(&readaccess,0,1);
	sem_init(&Reader_Change,0,1);
	sem_init(&writeaccess,0,1);
	sem_init(&Writer_Change,0,1);

	ifstream input("data.txt");

	if(!input.is_open()){
		exit(1);
	}

	char store[300];
	int index = 0;
	char temp;
	while(!input.eof()){
		input.read(&temp,1);
		if(temp!=' '&&temp!='\n'&&temp!='\r'){
			store[index]=temp;
			index++;
		//cout << temp << endl;	
		}
	}
	index = 0 ;
	for(int i = 0 ; i < sum ; i++){
		
		test[i].pid = store[index] -'0';
		index++;
		//cout << "========";
		//cout << test[i].pid << endl;
		test[i].role = store[index];
		index++;
		//cout << test[i].role << endl;
		test[i].StartTime = store[index]-'0';
		index++;
		//cout << test[i].StartTime;
		test[i].LastTime = store[index]-'0';
		index++;
	}

	for(int i = 0 ; i < sum ; i++){

		if(test[i].role == 'R'){
			pthread_create(&pid[i],NULL,Reader,&test[i]);
			cout << "CONSTRUCT A  READER PTHREAD NO."
			<<test[i].pid  << endl;
		}
		if(test[i].role == 'W'){
			pthread_create(&pid[i],NULL,Writer,&test[i]);
			cout << "CONSTRUCT A  WRITER PTHREAD NO."
			<<test[i].pid  << endl;
		}
	}
	for(int i = 0 ; i < sum ; i++){
		pthread_join(pid[i],NULL);
	}

	//sem_destroy(&read_write);
	//sem_destroy(&change);
	sem_destroy(&Writer_Change);
	sem_destroy(&Reader_Change);
	sem_destroy(&writeaccess);
	sem_destroy(&readaccess);


}

