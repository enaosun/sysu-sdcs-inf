

 dt = 0.01;
 t = -5:0.01:5;
 
 %����ԭ�����ź�
 f = 0*(abs(t)>pi) + 1/2*((cos(t)+1).*(abs(t)<=pi));
 
% figure(1);
 subplot(3,1,1);
 plot(t,f);
 xlabel('time');
 ylabel('f(t)');
 title('signal');
 
 N = length(f);
 n = 0:1:N-1;

 
 temp = zeros(N,N);
 
 k = 0:(N-1);
 wk = (2*pi)*k/(N*dt);
 for j = 1:N
     temp(j,:) =  exp(-1i*(2*pi)*(j-1)*n/N);
 end
 
F = (temp*f')'*dt;
 subplot(3,1,2);
 plot(wk,abs(F));
 ylabel('abs(F)');
 xlabel('wk');
 title('������');
 subplot(3,1,3);
 plot(wk,angle(F));
 ylabel('angle(F)');
 xlabel('wk');
 title('��λ��');
 
 

 
 
 
 
 