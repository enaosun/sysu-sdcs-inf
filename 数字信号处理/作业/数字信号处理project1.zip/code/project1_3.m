 dt = 1;
 t = -5:0.01:5;
 t2 = -5:dt:5;
 
 %����ԭ�����ź�
 f2 = 0*(abs(t)>pi) + 1/2*((cos(t)+1).*(abs(t)<=pi));
 f = 0*(abs(t2)>pi) + 1/2*((cos(t2)+1).*(abs(t2)<=pi));
 
 
% figure(1);
 subplot(3,1,1);
 plot(t,f2);
 xlabel('time');
 ylabel('f(t)');
 title('signal and sampling period T = 1');
 hold on;
 stem(t2,f,'filled');
 hold off;
 
 N = length(f);
 n = 0:1:N-1;

 
 temp = zeros(N,N);
 
 k = 0:(N-1);
 wk = (2*pi)*k/(N*dt);
 for j = 1:N
     temp(j,:) =  exp(-1i*(2*pi)*(j-1)*n/N);
 end
 
F = (temp*f')'*dt;
 subplot(3,1,2);
 plot(wk,abs(F));
 ylabel('abs(F)');
 xlabel('wk');
 title('������');
 subplot(3,1,3);
 plot(wk,angle(F));
 ylabel('angle(F)');
 xlabel('wk');
 title('��λ��')
 
 
   figure(2);
 T_N = ones(length(t2),1)*t - t2'*ones(1,length(t));
 wc = 2.4; %��߽�Ƶ
 wc_temp = wc/pi;
 x2 = f*sinc(wc_temp*T_N);
 subplot(3,1,1)
 plot(t,f2);
 title('singal');
 subplot(3,1,2);
 plot(t,x2);
 title('reconstruct signal and T = 1')
 subplot(3,1,3);
 plot(t,abs(f2-x2));
 title('error');