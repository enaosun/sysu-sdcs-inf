%��֪��ֵ
wp = 2*pi*3/15;
ws = 2*pi*5/15;
Rp = 0.3;
As = 40;
Fs = 15/(2*pi);
fp = 3/(2*pi);
fs = 5/(2*pi);
T = 1/Fs;


label = {'������˹LPF������Ӧ(dB)','�б�ѩ��I��LPF������Ӧ(dB)','��ԲLPF������Ӧ(dB)'};
label2 = {'������˹LPF��λ��Ӧ','�б�ѩ��I��LPF��λ��Ӧ','��ԲLPF��λ��Ӧ'};

for approximation = 1:3
    %Butterworth
    if approximation == 1
        Omgp = (2 / T) * tan(wp / 2);
        Omgs = (2 / T) * tan(ws / 2);
        [n, Omgc] = buttord(Omgp, Omgs, Rp, As, 's');
        [n1, wc1] = buttord(wp/pi, ws/pi, Rp, As);
        [bd1, ad1] = butter(n1, wc1);
        [H, w] = freqz(bd1, ad1);
        dbH = 20*log10(abs(H)/max(abs(H)));
    end
        
    %Chebyshev
    if approximation == 2
        [n2, wc2] = cheb1ord(wp/pi, ws/pi, Rp, As);
        [bd2, ad2] = cheby1(n2, Rp, wc2);
        [H, w2] = freqz(bd2, ad2);
        dbH = 20*log10(abs(H)/max(abs(H)));
        figure;
    end
    
    %Elliptic
    if approximation == 3
        [n3, wc3] = ellipord(wp/pi, ws/pi, Rp, As);
        [bd3, ad3] = ellip(n3, Rp, As, wc3);
        [H, w] = freqz(bd3, ad3);
        dbH = 20*log10(abs(H)/max(abs(H)));
        figure;
    end
        
        
        
    subplot(2, 1, 1);
    plot(w/2/pi*Fs, dbH, 'k');
    title(label(approximation)); axis([0, Fs / 2, -80, 5]);
    ylabel('dB');
    set(gca, 'XTickMode', 'manual', 'XTick', [0, fp, fs, Fs / 2]);
    set(gca, 'YTickMode', 'manual', 'YTick', [-50, -40, -0.3, 0]); 
    grid;
    subplot(2, 1, 2);
    plot(w/2/pi*Fs, angle(H)/pi*180, 'k');
    title(label2(approximation)); axis([0, Fs/2, -180, 180]);
    ylabel('\phi');
    set(gca, 'XTickMode', 'manual', 'XTick', [0, fp, fs, Fs / 2]);
    set(gca, 'YTickMode', 'manual', 'YTick', [-180, 0, 180]);
    grid;
    
end

